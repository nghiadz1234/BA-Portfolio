import express from "express";
import { createServer as createViteServer } from "vite";
import path from "path";
import { fileURLToPath } from "url";
import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';
import { pool } from './src/lib/mysql_db';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const JWT_SECRET = 'your-secret-key-task-manager';

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // Ensure notifications table exists
  try {
    await pool.execute(`
      CREATE TABLE IF NOT EXISTS notifications (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT NOT NULL,
        title VARCHAR(255) NOT NULL,
        message TEXT,
        is_read TINYINT(1) DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES accounts(id)
      )
    `);
    console.log('Database notifications table checked/created');
  } catch (err) {
    console.error('Error creating notifications table:', err);
  }

  // Migration: Add priority column to projects if it doesn't exist
  try {
    const [rows]: any = await pool.execute('SHOW COLUMNS FROM projects LIKE "priority"');
    if (rows.length === 0) {
      await pool.execute('ALTER TABLE projects ADD COLUMN priority VARCHAR(20) DEFAULT "medium"');
      console.log('Migration: Added priority column to projects table');
    }
  } catch (err) {
    console.error('Migration error (projects priority):', err);
  }

  // Migration: Create task_evaluations table if it doesn't exist
  try {
    await pool.execute(`
      CREATE TABLE IF NOT EXISTS task_evaluations (
        id INT AUTO_INCREMENT PRIMARY KEY,
        task_id INT NOT NULL,
        employee_id INT NOT NULL,
        rating INT,
        comment TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `);
    console.log('Migration: Checked task_evaluations table');
  } catch (err) {
    console.error('Migration error (task_evaluations):', err);
  }

  // Migration: Create user_profiles table
  try {
    await pool.execute(`
      CREATE TABLE IF NOT EXISTS user_profiles (
        id INT AUTO_INCREMENT PRIMARY KEY,
        account_id INT UNIQUE NOT NULL,
        email VARCHAR(100),
        phone VARCHAR(20),
        address TEXT,
        bio TEXT,
        avatar_url TEXT,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        FOREIGN KEY (account_id) REFERENCES accounts(id) ON DELETE CASCADE
      )
    `);
    console.log('Migration: Checked user_profiles table');
  } catch (err) {
    console.error('Migration error (user_profiles):', err);
  }

  // Migration: Create employee_reports table
  try {
    await pool.execute(`
      CREATE TABLE IF NOT EXISTS employee_reports (
        id INT AUTO_INCREMENT PRIMARY KEY,
        employee_id INT NOT NULL,
        reporter_id INT NOT NULL,
        content TEXT NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (employee_id) REFERENCES accounts(id) ON DELETE CASCADE,
        FOREIGN KEY (reporter_id) REFERENCES accounts(id) ON DELETE CASCADE
      )
    `);
    console.log('Migration: Checked employee_reports table');
  } catch (err) {
    console.error('Migration error (employee_reports):', err);
  }

  // Authentication Middleware
  const authenticate = (req: any, res: any, next: any) => {
    const token = req.headers.authorization?.split(' ')[1];
    if (!token) return res.status(401).json({ message: 'Unauthorized' });

    try {
      const decoded = jwt.verify(token, JWT_SECRET);
      req.user = decoded;
      next();
    } catch (error) {
      res.status(401).json({ message: 'Invalid token' });
    }
  };

  // Auth APIs
  app.post("/api/login", async (req, res) => {
    const { username, password } = req.body;
    console.log(`Đang thử đăng nhập: User=${username}, Pass=${password}`);
    
    try {
      const [rows]: any = await pool.execute('SELECT * FROM accounts WHERE username = ?', [username]);
      const user = rows[0];

      if (!user) {
        console.log('=> Lỗi: Không tìm thấy username này trong DB');
        return res.status(401).json({ message: 'Sai tài khoản hoặc mật khẩu' });
      }

      console.log(`=> Tìm thấy user trong DB: ID=${user.id}, Role=${user.role}, Password_Trong_DB=${user.password}`);

      if (password !== user.password) {
        console.log('=> Lỗi: Mật khẩu không khớp!');
        return res.status(401).json({ message: 'Sai tài khoản hoặc mật khẩu' });
      }

      console.log('=> Đăng nhập thành công!');
      const token = jwt.sign({ 
        id: user.id, 
        username: user.username, 
        role: user.role,
        fullname: user.fullname 
      }, JWT_SECRET, { expiresIn: '1d' });

      res.json({ token, user: { id: user.id, username: user.username, role: user.role, fullname: user.fullname } });
    } catch (err: any) {
      console.error('Lỗi SQL chi tiết:', err);
      res.status(500).json({ 
        message: 'Lỗi Database: ' + err.message,
        hint: 'Hãy kiểm tra XAMPP và Database.' 
      });
    }
  });

  // Projects APIs
  app.get("/api/projects", authenticate, async (req, res) => {
    try {
      const [projects] = await pool.execute('SELECT * FROM projects');
      res.json(projects);
    } catch (err: any) {
      res.status(500).json({ message: 'Lỗi Database: ' + err.message });
    }
  });

  app.post("/api/projects", authenticate, async (req: any, res) => {
    if (req.user.role !== 'admin') return res.status(403).json({ message: 'No permission' });
    const { name, description, status, priority, tasks } = req.body;
    
    const connection = await pool.getConnection();
    try {
      await connection.beginTransaction();
      
      const [pResult]: any = await connection.execute(
        'INSERT INTO projects (name, description, status, priority, manager_id) VALUES (?, ?, ?, ?, ?)', 
        [name, description, status || 'active', priority || 'medium', req.user.id]
      );
      const projectId = pResult.insertId;

      if (tasks && Array.isArray(tasks)) {
        for (const task of tasks) {
          await connection.execute(
            'INSERT INTO tasks (project_id, title, description, assigned_to, due_date, status) VALUES (?, ?, ?, ?, ?, ?)',
            [projectId, task.title, task.description || '', task.assigned_to, task.due_date || null, 'todo']
          );

          if (task.assigned_to) {
            await connection.execute(
              'INSERT INTO notifications (user_id, title, message) VALUES (?, ?, ?)',
              [task.assigned_to, 'Công việc mới', `Bạn đã được giao công việc "${task.title}" trong dự án "${name}"`]
            );
          }
        }
      }

      await connection.commit();
      res.json({ id: projectId });
    } catch (err: any) {
      await connection.rollback();
      res.status(500).json({ message: 'Lỗi Database: ' + err.message });
    } finally {
      connection.release();
    }
  });

  app.get("/api/notifications", authenticate, async (req: any, res) => {
    try {
      const [rows] = await pool.execute(
        'SELECT * FROM notifications WHERE user_id = ? ORDER BY created_at DESC LIMIT 50', 
        [req.user.id]
      );
      res.json(rows);
    } catch (err: any) {
      res.status(500).json({ message: 'Lỗi Database: ' + err.message });
    }
  });

  app.put("/api/notifications/read", authenticate, async (req: any, res) => {
    try {
      await pool.execute('UPDATE notifications SET is_read = 1 WHERE user_id = ?', [req.user.id]);
      res.json({ message: 'Updated' });
    } catch (err: any) {
      res.status(500).json({ message: 'Lỗi Database: ' + err.message });
    }
  });

  app.put("/api/projects/:id", authenticate, async (req: any, res) => {
    if (req.user.role !== 'admin') return res.status(403).json({ message: 'No permission' });
    const { name, description, status, priority } = req.body;
    try {
      await pool.execute('UPDATE projects SET name = ?, description = ?, status = ?, priority = ? WHERE id = ?', [name, description, status, priority, req.params.id]);
      res.json({ message: 'Updated' });
    } catch (err: any) {
      res.status(500).json({ message: 'Lỗi Database: ' + err.message });
    }
  });

  app.delete("/api/projects/:id", authenticate, async (req: any, res) => {
    if (req.user.role !== 'admin') return res.status(403).json({ message: 'No permission' });
    const connection = await pool.getConnection();
    try {
      await connection.beginTransaction();
      // Xóa các task liên quan trước
      await connection.execute('DELETE FROM tasks WHERE project_id = ?', [req.params.id]);
      // Sau đó mới xóa dự án
      await connection.execute('DELETE FROM projects WHERE id = ?', [req.params.id]);
      await connection.commit();
      res.json({ message: 'Deleted' });
    } catch (err: any) {
      await connection.rollback();
      res.status(500).json({ message: 'Lỗi Database: ' + err.message });
    } finally {
      connection.release();
    }
  });

  // Tasks APIs
  app.get("/api/tasks", authenticate, async (req: any, res) => {
    try {
      let rows: any;
      if (req.user.role === 'admin') {
        // Quản lý thấy: Công việc đang đợi Duyệt (review) HOẶC công việc giao cho mình
        const [tasks] = await pool.execute(`
          SELECT tasks.*, projects.name as project_name, accounts.fullname as assigned_name 
          FROM tasks 
          JOIN projects ON tasks.project_id = projects.id
          LEFT JOIN accounts ON tasks.assigned_to = accounts.id
          WHERE tasks.status = 'review' OR tasks.assigned_to = ?
        `, [req.user.id]);
        rows = tasks;
      } else {
        // Nhân viên thấy: Công việc giao cho mình và CHƯA hoàn thành (ẩn khi xong)
        const [tasks] = await pool.execute(`
          SELECT tasks.*, projects.name as project_name, accounts.fullname as assigned_name 
          FROM tasks 
          JOIN projects ON tasks.project_id = projects.id
          LEFT JOIN accounts ON tasks.assigned_to = accounts.id
          WHERE tasks.assigned_to = ? AND tasks.status != 'completed'
        `, [req.user.id]);
        rows = tasks;
      }
      res.json(rows);
    } catch (err: any) {
      res.status(500).json({ message: 'Lỗi Database: ' + err.message });
    }
  });

  // New endpoint to get ALL tasks for a project (for Project Details view)
  app.get("/api/projects/:id/tasks", authenticate, async (req: any, res) => {
    try {
      const [tasks] = await pool.execute(`
        SELECT tasks.*, projects.name as project_name, accounts.fullname as assigned_name 
        FROM tasks 
        JOIN projects ON tasks.project_id = projects.id
        LEFT JOIN accounts ON tasks.assigned_to = accounts.id
        WHERE tasks.project_id = ?
      `, [req.params.id]);
      res.json(tasks);
    } catch (err: any) {
      res.status(500).json({ message: 'Lỗi Database: ' + err.message });
    }
  });

  app.post("/api/tasks", authenticate, async (req: any, res) => {
    if (req.user.role !== 'admin') return res.status(403).json({ message: 'No permission' });
    const { project_id, title, description, assigned_to, due_date, status } = req.body;
    try {
      const [result]: any = await pool.execute(
        'INSERT INTO tasks (project_id, title, description, assigned_to, due_date, status) VALUES (?, ?, ?, ?, ?, ?)', 
        [project_id, title, description, assigned_to, due_date, status || 'todo']
      );
      res.json({ id: result.insertId });
    } catch (err: any) {
      res.status(500).json({ message: 'Lỗi Database: ' + err.message });
    }
  });

  app.put("/api/tasks/:id", authenticate, async (req: any, res) => {
    const { status, title, description, assigned_to, due_date, project_id } = req.body;
    const taskId = req.params.id;
    
    try {
      const [currentTasks]: any = await pool.execute('SELECT * FROM tasks WHERE id = ?', [taskId]);
      if (currentTasks.length === 0) return res.status(404).json({ message: 'Task not found' });
      const task = currentTasks[0];

      let newStatus = status;

      // Logic chuyển trạng thái và thông báo tự động
      if (req.user.role !== 'admin' && status === 'completed') {
        newStatus = 'review'; // Nhân viên bấm hoàn thành -> Chờ Manager duyệt
        
        // Gửi thông báo cho Manager dự án (lấy manager_id từ project)
        const [pData]: any = await pool.execute('SELECT manager_id FROM projects WHERE id = ?', [task.project_id]);
        if (pData.length > 0) {
          await pool.execute(
            'INSERT INTO notifications (user_id, title, message) VALUES (?, ?, ?)',
            [pData[0].manager_id, 'Công việc chờ duyệt', `Nhân viên ${req.user.fullname} đã đăng ký hoàn thành công việc "${task.title}".`]
          );
        }
      }

      if (req.user.role === 'admin') {
        await pool.execute(
          'UPDATE tasks SET project_id = ?, title = ?, description = ?, assigned_to = ?, due_date = ?, status = ? WHERE id = ?',
          [project_id || task.project_id, title || task.title, description || task.description, assigned_to || task.assigned_to, due_date || task.due_date, newStatus, taskId]
        );
        
        // Nếu Admin duyệt "Hoàn thành" thực sự -> Thông báo nhân viên và nó sẽ biến mất khỏi danh sách của họ
        if (newStatus === 'completed' && task.assigned_to) {
          await pool.execute(
            'INSERT INTO notifications (user_id, title, message) VALUES (?, ?, ?)',
            [task.assigned_to, 'Công việc hoàn tất', `Công việc "${task.title}" của bạn đã được quản lý phê duyệt.`]
          );

          // Tự động kiểm tra và hoàn thành dự án nếu tất cả task đã xong
          const [allTasks]: any = await pool.execute('SELECT status FROM tasks WHERE project_id = ?', [task.project_id]);
          const totalTasks = allTasks.length;
          const completedTasks = allTasks.filter((t: any) => t.status === 'completed').length;
          
          if (totalTasks > 0 && totalTasks === completedTasks) {
            await pool.execute('UPDATE projects SET status = "completed" WHERE id = ?', [task.project_id]);
            // Thông báo cho manager dự án
            const [pInfo]: any = await pool.execute('SELECT manager_id, name FROM projects WHERE id = ?', [task.project_id]);
            if (pInfo.length > 0) {
              await pool.execute(
                'INSERT INTO notifications (user_id, title, message) VALUES (?, ?, ?)',
                [pInfo[0].manager_id, 'Dự án đã hoàn thành', `Tất cả công việc trong dự án "${pInfo[0].name}" đã hoàn thành. Trạng thái dự án được cập nhật thành Hoàn thành.`]
              );
            }
          }
        }
      } else {
        await pool.execute('UPDATE tasks SET status = ? WHERE id = ?', [newStatus, taskId]);
      }

      res.json({ message: 'Updated', status: newStatus });
    } catch (err: any) {
      res.status(500).json({ message: 'Lỗi Database: ' + err.message });
    }
  });

  app.post("/api/tasks/:id/evaluate", authenticate, async (req: any, res) => {
    if (req.user.role !== 'admin') return res.status(403).json({ message: 'No permission' });
    const { rating, comment, employee_id } = req.body;
    const task_id = req.params.id;
    try {
      await pool.execute(
        'INSERT INTO task_evaluations (task_id, employee_id, rating, comment) VALUES (?, ?, ?, ?)',
        [task_id, employee_id, rating, comment]
      );
      
      // Notify employee about the evaluation
      await pool.execute(
        'INSERT INTO notifications (user_id, title, message) VALUES (?, ?, ?)',
        [employee_id, 'Bạn có đánh giá mới', `Quản lý đã đánh giá công việc của bạn: ${rating}/5 sao.`]
      );

      res.json({ message: 'Evaluated' });
    } catch (err: any) {
      res.status(500).json({ message: 'Lỗi Database: ' + err.message });
    }
  });

  app.get("/api/tasks/:id/evaluation", authenticate, async (req: any, res) => {
    try {
      const [rows]: any = await pool.execute('SELECT * FROM task_evaluations WHERE task_id = ?', [req.params.id]);
      res.json(rows[0] || null);
    } catch (err: any) {
      res.status(500).json({ message: 'Lỗi Database: ' + err.message });
    }
  });

  app.delete("/api/tasks/:id", authenticate, async (req: any, res) => {
    if (req.user.role !== 'admin') return res.status(403).json({ message: 'No permission' });
    try {
      await pool.execute('DELETE FROM tasks WHERE id = ?', [req.params.id]);
      res.json({ message: 'Deleted' });
    } catch (err: any) {
      res.status(500).json({ message: 'Lỗi Database: ' + err.message });
    }
  });

  // User Profile Endpoints
  app.get("/api/profile", authenticate, async (req: any, res) => {
    try {
      const [rows]: any = await pool.execute('SELECT * FROM user_profiles WHERE account_id = ?', [req.user.id]);
      if (rows.length === 0) {
        // Initialize profile if not exists
        await pool.execute('INSERT INTO user_profiles (account_id) VALUES (?)', [req.user.id]);
        const [newRows]: any = await pool.execute('SELECT * FROM user_profiles WHERE account_id = ?', [req.user.id]);
        return res.json(newRows[0]);
      }
      res.json(rows[0]);
    } catch (err: any) {
      res.status(500).json({ message: 'Lỗi Database: ' + err.message });
    }
  });

  app.put("/api/profile", authenticate, async (req: any, res) => {
    const { email, phone, address, bio, avatar_url } = req.body;
    try {
      await pool.execute(
        'UPDATE user_profiles SET email = ?, phone = ?, address = ?, bio = ?, avatar_url = ? WHERE account_id = ?',
        [email || null, phone || null, address || null, bio || null, avatar_url || null, req.user.id]
      );
      res.json({ message: 'Cập nhật thành công' });
    } catch (err: any) {
      res.status(500).json({ message: 'Lỗi Database: ' + err.message });
    }
  });

  // Employees List
  app.get("/api/employees", authenticate, async (req, res) => {
    try {
      const [employees] = await pool.execute('SELECT id, username, role, fullname FROM accounts');
      res.json(employees);
    } catch (err: any) {
      res.status(500).json({ message: 'Lỗi Database: ' + err.message });
    }
  });

  app.post("/api/employees", authenticate, async (req: any, res) => {
    if (req.user.role !== 'admin') return res.status(403).json({ message: 'No permission' });
    const { username, password, fullname, role } = req.body;
    try {
      // Check if username exists
      const [existing]: any = await pool.execute('SELECT id FROM accounts WHERE username = ?', [username]);
      if (existing.length > 0) {
        return res.status(400).json({ message: 'Tên đăng nhập đã tồn tại' });
      }

      await pool.execute(
        'INSERT INTO accounts (username, password, fullname, role) VALUES (?, ?, ?, ?)',
        [username, password, fullname, role || 'employee']
      );
      res.json({ message: 'Đã thêm nhân viên' });
    } catch (err: any) {
      res.status(500).json({ message: 'Lỗi Database: ' + err.message });
    }
  });

  app.delete("/api/employees/:id", authenticate, async (req: any, res) => {
    if (req.user.role !== 'admin') return res.status(403).json({ message: 'No permission' });
    const targetId = parseInt(req.params.id);
    if (targetId === req.user.id) return res.status(400).json({ message: 'Không thể tự xóa chính mình' });
    
    try {
      // Handle foreign keys manually to avoid "lock/constraint" errors
      await pool.execute('DELETE FROM task_evaluations WHERE employee_id = ?', [targetId]);
      await pool.execute('UPDATE tasks SET assigned_to = NULL WHERE assigned_to = ?', [targetId]);
      await pool.execute('DELETE FROM user_profiles WHERE account_id = ?', [targetId]);
      
      const [result]: any = await pool.execute('DELETE FROM accounts WHERE id = ?', [targetId]);
      
      if (result.affectedRows === 0) {
        return res.status(404).json({ message: 'Không tìm thấy nhân viên' });
      }
      
      res.json({ message: 'Đã xóa nhân viên thành công' });
    } catch (err: any) {
      console.error('Delete error:', err);
      res.status(500).json({ message: 'Lỗi Database: ' + err.message });
    }
  });

  app.get("/api/employees/:id/work", authenticate, async (req, res) => {
    try {
      const [tasks]: any = await pool.execute(`
        SELECT t.*, p.name as project_name 
        FROM tasks t 
        LEFT JOIN projects p ON t.project_id = p.id 
        WHERE t.assigned_to = ?
      `, [req.params.id]);
      
      const [projects]: any = await pool.execute(`
        SELECT DISTINCT p.* 
        FROM projects p
        JOIN tasks t ON p.id = t.project_id
        WHERE t.assigned_to = ?
      `, [req.params.id]);

      // Also fetch evaluations for AI report context
      const [evals]: any = await pool.execute(`
        SELECT e.*, t.title as task_title, p.name as project_name
        FROM task_evaluations e
        JOIN tasks t ON e.task_id = t.id
        LEFT JOIN projects p ON t.project_id = p.id
        WHERE e.employee_id = ?
        ORDER BY e.created_at DESC
      `, [req.params.id]);

      res.json({ tasks, projects, evaluations: evals });
    } catch (err: any) {
      res.status(500).json({ message: 'Lỗi Database: ' + err.message });
    }
  });

  // Reports Endpoints
  app.get("/api/reports", authenticate, async (req: any, res) => {
    try {
      let query = `
        SELECT r.*, e.fullname as employee_name, rep.fullname as reporter_name
        FROM employee_reports r
        JOIN accounts e ON r.employee_id = e.id
        JOIN accounts rep ON r.reporter_id = rep.id
      `;
      const params = [];
      if (req.user.role !== 'admin') {
        query += " WHERE r.employee_id = ?";
        params.push(req.user.id);
      }
      query += " ORDER BY r.created_at DESC";
      
      const [rows]: any = await pool.execute(query, params);
      res.json(rows);
    } catch (err: any) {
      res.status(500).json({ message: 'Lỗi Database: ' + err.message });
    }
  });

  app.post("/api/reports", authenticate, async (req: any, res) => {
    if (req.user.role !== 'admin') return res.status(403).json({ message: 'No permission' });
    const { employee_id, content } = req.body;
    try {
      await pool.execute(
        'INSERT INTO employee_reports (employee_id, reporter_id, content) VALUES (?, ?, ?)',
        [employee_id, req.user.id, content]
      );
      res.json({ message: 'Đã lưu báo cáo thành công' });
    } catch (err: any) {
      res.status(500).json({ message: 'Lỗi Database: ' + err.message });
    }
  });

  app.delete("/api/reports/:id", authenticate, async (req: any, res) => {
    if (req.user.role !== 'admin') return res.status(403).json({ message: 'No permission' });
    try {
      await pool.execute('DELETE FROM employee_reports WHERE id = ?', [req.params.id]);
      res.json({ message: 'Đã xóa báo cáo' });
    } catch (err: any) {
      res.status(500).json({ message: 'Lỗi Database: ' + err.message });
    }
  });

  // AI Report generation is now handled on the frontend for better compatibility with AI Studio keys

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req: any, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running at http://localhost:${PORT}`);
  });
}

startServer();
