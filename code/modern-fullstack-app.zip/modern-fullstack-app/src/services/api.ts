import { Project, Task, User, Account } from '../types';

const getHeaders = () => ({
  'Content-Type': 'application/json',
  'Authorization': `Bearer ${localStorage.getItem('token')}`
});

export const apiService = {
  async login(username: string, password: string): Promise<{ token: string, user: User }> {
    const response = await fetch('/api/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username, password })
    });
    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.message || 'Login failed');
    }
    return await response.json();
  },

  async fetchProjects(): Promise<Project[]> {
    const response = await fetch('/api/projects', { headers: getHeaders() });
    if (!response.ok) return [];
    return await response.json();
  },

  async createProject(project: Partial<Project>): Promise<any> {
    const response = await fetch('/api/projects', {
      method: 'POST',
      headers: getHeaders(),
      body: JSON.stringify(project)
    });
    return await response.json();
  },

  async updateProject(id: number, project: Partial<Project>): Promise<any> {
    const response = await fetch(`/api/projects/${id}`, {
      method: 'PUT',
      headers: getHeaders(),
      body: JSON.stringify(project)
    });
    return await response.json();
  },

  async deleteProject(id: number): Promise<any> {
    const response = await fetch(`/api/projects/${id}`, {
      method: 'DELETE',
      headers: getHeaders()
    });
    return await response.json();
  },

  async fetchTasks(): Promise<Task[]> {
    const response = await fetch('/api/tasks', { headers: getHeaders() });
    if (!response.ok) return [];
    return await response.json();
  },

  async fetchProjectTasks(projectId: number): Promise<Task[]> {
    const response = await fetch(`/api/projects/${projectId}/tasks`, { headers: getHeaders() });
    if (!response.ok) return [];
    return await response.json();
  },

  async createTask(task: Partial<Task>): Promise<any> {
    const response = await fetch('/api/tasks', {
      method: 'POST',
      headers: getHeaders(),
      body: JSON.stringify(task)
    });
    return await response.json();
  },

  async updateTask(id: number, task: Partial<Task>): Promise<any> {
    const response = await fetch(`/api/tasks/${id}`, {
      method: 'PUT',
      headers: getHeaders(),
      body: JSON.stringify(task)
    });
    return await response.json();
  },

  async deleteTask(id: number): Promise<any> {
    const response = await fetch(`/api/tasks/${id}`, {
      method: 'DELETE',
      headers: getHeaders()
    });
    return await response.json();
  },

  async fetchEmployees(): Promise<Account[]> {
    const response = await fetch('/api/employees', { headers: getHeaders() });
    if (!response.ok) return [];
    return await response.json();
  },

  async fetchNotifications(): Promise<Notification[]> {
    const response = await fetch('/api/notifications', { headers: getHeaders() });
    if (!response.ok) return [];
    return await response.json();
  },

  async markNotificationsRead(): Promise<any> {
    const response = await fetch('/api/notifications/read', {
      method: 'PUT',
      headers: getHeaders()
    });
    return await response.json();
  }
};
