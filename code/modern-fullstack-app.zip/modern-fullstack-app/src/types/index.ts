export type UserRole = 'admin' | 'employee';

export interface User {
  id: number;
  username: string;
  role: UserRole;
  fullname: string;
}

export interface Project {
  id: number;
  name: string;
  description: string;
  manager_id: number;
  status: string;
  priority: string;
  created_at: string;
}

export interface Task {
  id: number;
  project_id: number;
  project_name?: string;
  title: string;
  description: string;
  assigned_to: number;
  assigned_name?: string;
  status: string;
  due_date: string;
}

export interface Evaluation {
  id?: number;
  task_id: number;
  employee_id: number;
  rating: number;
  comment: string;
  created_at?: string;
  employee_name?: string;
}

export interface UserProfile {
  id?: number;
  account_id: number;
  email: string | null;
  phone: string | null;
  address: string | null;
  bio: string | null;
  avatar_url: string | null;
  updated_at?: string;
}

export interface Account {
  id: number;
  username: string;
  role: UserRole;
  fullname: string;
}

export interface Notification {
  id: number;
  user_id: number;
  title: string;
  message: string;
  is_read: number;
  created_at: string;
}
