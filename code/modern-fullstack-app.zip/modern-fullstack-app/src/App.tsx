/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useEffect, useState, FormEvent, ReactNode } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Database, Server, Layout, Activity, ChevronRight, HardDrive, 
  Users, Briefcase, ClipboardList, BarChart3, LogOut, User as UserIcon,
  Plus, Search, Shield, Filter, Bell, Star, Brain
} from 'lucide-react';
import { apiService } from './services/api';
import { User, Project, Task, Account } from './types';
import { jsPDF } from "jspdf";
import html2canvas from "html2canvas";
import { GoogleGenAI } from "@google/genai";

export default function App() {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [activeTab, setActiveTab] = useState<'projects' | 'tasks' | 'employees' | 'reports'>('projects');
  const [projects, setProjects] = useState<Project[]>([]);
  const [tasks, setTasks] = useState<Task[]>([]);
  const [employees, setEmployees] = useState<Account[]>([]);
  const [notifications, setNotifications] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [showNotifPanel, setShowNotifPanel] = useState(false);
  const [projectsSearch, setProjectsSearch] = useState('');
  const [tasksSearch, setTasksSearch] = useState('');
  const [employeesSearch, setEmployeesSearch] = useState('');
  const [evaluation, setEvaluation] = useState<any>(null);
  const [evalData, setEvalData] = useState({ rating: 5, comment: '' });
  const [profile, setProfile] = useState<any>(null);
  const [isEditingProfile, setIsEditingProfile] = useState(false);
  const [profileForm, setProfileForm] = useState({
    email: '', phone: '', address: '', bio: '', avatar_url: ''
  });
  const [selectedEmployeeWork, setSelectedEmployeeWork] = useState<any>(null);
  const [selectedEmployee, setSelectedEmployee] = useState<any>(null);
  const [employeeFormData, setEmployeeFormData] = useState({
    username: '', password: '', fullname: '', role: 'employee'
  });
  const [reports, setReports] = useState<any[]>([]);
  const [selectedReportEmployeeId, setSelectedReportEmployeeId] = useState<string>('');
  const [aiReportContent, setAiReportContent] = useState<string>('');
  const [managerNote, setManagerNote] = useState<string>('');
  const [isGeneratingAI, setIsGeneratingAI] = useState(false);
  const [viewingReport, setViewingReport] = useState<any>(null);
  const [reportTab, setReportTab] = useState<'generate' | 'history'>('generate');

  useEffect(() => {
    if (currentUser && currentUser.role !== 'admin' && reportTab === 'generate') {
      setReportTab('history');
    }
  }, [currentUser, reportTab]);

  const unreadCount = notifications.filter(n => !n.is_read).length;
  const [authForm, setAuthForm] = useState({ username: '', password: '' });
  const [error, setError] = useState('');

  // UI state for Modals
  const [showModal, setShowModal] = useState<'project' | 'task' | 'view_project' | 'view_task' | null>(null);
  const [editingItem, setEditingItem] = useState<any>(null);
  const [formData, setFormData] = useState<any>({});
  const [viewingProjectTasks, setViewingProjectTasks] = useState<Task[]>([]);

  useEffect(() => {
    const savedUser = localStorage.getItem('user');
    if (savedUser) {
      setCurrentUser(JSON.parse(savedUser));
    }
  }, []);

  useEffect(() => {
    if (currentUser) {
      fetchData();
      const interval = setInterval(fetchNotifs, 10000); // Polling every 10s
      return () => clearInterval(interval);
    }
  }, [currentUser, activeTab]);

  useEffect(() => {
    if (currentUser && activeTab === 'profile') {
      fetchProfile();
    }
    if (currentUser && activeTab === 'reports') {
      fetchReports();
    }
  }, [activeTab, currentUser]);

  const isAdmin = currentUser?.role === 'admin';

  const filteredProjects = projects.filter(p => 
    p.status !== 'completed' && (
      p.name.toLowerCase().includes(projectsSearch.toLowerCase()) || 
      (p.description && p.description.toLowerCase().includes(projectsSearch.toLowerCase()))
    )
  );

  const filteredTasks = tasks.filter(t => 
    t.title.toLowerCase().includes(tasksSearch.toLowerCase()) || 
    (t.description && t.description.toLowerCase().includes(tasksSearch.toLowerCase())) ||
    (t.project_name && t.project_name.toLowerCase().includes(tasksSearch.toLowerCase())) ||
    (t.assigned_name && t.assigned_name.toLowerCase().includes(tasksSearch.toLowerCase()))
  );

  const filteredEmployees = employees.filter(e => 
    e.fullname.toLowerCase().includes(employeesSearch.toLowerCase()) || 
    e.username.toLowerCase().includes(employeesSearch.toLowerCase())
  );

  const fetchNotifs = async () => {
    try {
      const notifs = await apiService.fetchNotifications();
      setNotifications(notifs);
    } catch (e) {
      console.error('Lỗi khi lấy thông báo', e);
    }
  };

  const handleMarkRead = async () => {
    try {
      await apiService.markNotificationsRead();
      fetchNotifs();
      setShowNotifPanel(false);
    } catch (e) {
      console.error(e);
    }
  };

  const fetchData = async () => {
    setLoading(true);
    try {
      fetchNotifs();
      
      // Luôn lấy dữ liệu dự án và nhân viên nếu đang ở các tab liên quan hoặc đang mở Modal
      if (activeTab === 'projects' || activeTab === 'tasks' || showModal === 'task' || showModal === 'project') {
        const pData = await apiService.fetchProjects();
        setProjects(pData);
        
        const eData = await apiService.fetchEmployees();
        setEmployees(eData);
      }
      
      if (activeTab === 'tasks') {
        const tData = await apiService.fetchTasks();
        setTasks(tData);
      } else if (activeTab === 'employees') {
        const eData = await apiService.fetchEmployees();
        setEmployees(eData);
      }

      if (showModal === 'view_project' && editingItem) {
        const pTasks = await apiService.fetchProjectTasks(editingItem.id);
        setViewingProjectTasks(pTasks);
      }

    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleLogin = async (e: FormEvent) => {
    e.preventDefault();
    setError('');
    try {
      const res = await apiService.login(authForm.username, authForm.password);
      localStorage.setItem('token', res.token);
      localStorage.setItem('user', JSON.stringify(res.user));
      setCurrentUser(res.user);
    } catch (err: any) {
      setError(err.message);
    }
  };

  const handleLogout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    setCurrentUser(null);
  };

  const openCreateModal = (type: 'project' | 'task' | 'employee') => {
    setEditingItem(null);
    if (type === 'project') {
      setFormData({ name: '', description: '', status: 'active', priority: 'medium', tasks: [] });
    } else if (type === 'task') {
      setFormData({ title: '', description: '', project_id: '', assigned_to: '', status: 'todo', due_date: '' });
    } else if (type === 'employee') {
      setEmployeeFormData({ username: '', password: '', fullname: '', role: 'employee' });
    }
    setShowModal(type);
  };

  const handleDeleteEmployee = async (id: number) => {
    if (!confirm('Bạn có chắc chắn muốn xóa nhân viên này?')) return;
    try {
      const resp = await fetch(`/api/employees/${id}`, {
        method: 'DELETE',
        headers: { 'Authorization': `Bearer ${localStorage.getItem('token')}` }
      });
      if (resp.ok) fetchData();
      else {
        const data = await resp.json();
        alert(data.message);
      }
    } catch (err) {
      console.error(err);
    }
  };

  const openViewEmployee = async (employee: any) => {
    setSelectedEmployee(employee);
    try {
      const resp = await fetch(`/api/employees/${employee.id}/work`, {
        headers: { 'Authorization': `Bearer ${localStorage.getItem('token')}` }
      });
      const data = await resp.json();
      setSelectedEmployeeWork(data);
      setShowModal('view_employee');
    } catch (err) {
      console.error(err);
    }
  };

  const fetchReports = async () => {
    try {
      const resp = await fetch('/api/reports', {
        headers: { 'Authorization': `Bearer ${localStorage.getItem('token')}` }
      });
      const data = await resp.json();
      setReports(data);
    } catch (err) {
      console.error(err);
    }
  };

  const generateAIReport = async () => {
    if (!selectedReportEmployeeId) return alert('Vui lòng chọn nhân viên');
    setIsGeneratingAI(true);
    setAiReportContent('');
    
    try {
      // Step 1: Fetch evaluations for the employee
      const resp = await fetch(`/api/employees/${selectedReportEmployeeId}/work`, {
        headers: { 'Authorization': `Bearer ${localStorage.getItem('token')}` }
      });
      const contextData = await resp.json();
      
      if (!contextData.evaluations || contextData.evaluations.length === 0) {
        setIsGeneratingAI(false);
        return alert('Nhân viên này chưa có đánh giá nào từ quản lý để tổng hợp.');
      }

      // Step 2: Use GoogleGenAI on client-side
      const apiKey = (import.meta as any).env.VITE_APP_GEMINI_KEY || 
                     (import.meta as any).env.VITE_GEMINI_API_KEY || 
                     process.env.GEMINI_API_KEY;

      if (!apiKey || apiKey === 'undefined') {
        throw new Error('Không tìm thấy API Key. Vui lòng kiểm tra lại tệp .env hoặc thiết lập APP_GEMINI_KEY.');
      }

      const ai = new GoogleGenAI({ apiKey });
      const employeeName = employees.find(e => e.id === parseInt(selectedReportEmployeeId))?.fullname || 'Nhân viên';

      const prompt = `Bạn là một chuyên gia nhân sự chuyên nghiệp. Hãy phân tích các dữ liệu đánh giá sau đây của quản lý về nhân viên "${employeeName}" và viết một bản báo cáo tổng kết chi tiết.
      
      Yêu cầu cấu trúc báo cáo:
      1. TỔNG QUAN HIỆU SUẤT: Tóm tắt ngắn gọn thái độ và kết quả làm việc.
      2. ƯU ĐIỂM CHI TIẾT: Liệt kê các điểm mạnh dựa trên các công việc đã hoàn thành tốt.
      3. ĐIỂM CẦN CẢI THIỆN: Chỉ ra các kỹ năng hoặc vấn đề cần tối ưu hơn (nếu có).
      4. ĐÁNH GIÁ CHUNG: Đưa ra nhận xét cuối cùng và xếp loại (Tốt, Khá, Trung bình).

      Dữ liệu đánh giá từ hệ thống:
      ${contextData.evaluations.map((e: any) => `- Công việc: ${e.task_title} (Dự án ${e.project_name}). Điểm số: ${e.rating}/5. Nhận xét của quản lý: "${e.comment}"`).join('\n')}
      
      Hãy viết bằng tiếng Việt, văn phong chuyên nghiệp, khách quan và mang tính xây dựng.`;

      const aiResponse = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: prompt
      });

      const text = aiResponse.text;
      setAiReportContent(text || 'Không thể tạo báo cáo.');
    } catch (err: any) {
      console.error('AI Export Error:', err);
      alert('Lỗi khi tạo báo cáo AI: ' + err.message);
    } finally {
      setIsGeneratingAI(false);
    }
  };

  const handleSaveReport = async () => {
    if (!selectedReportEmployeeId || !aiReportContent) return alert('Dữ liệu không hoàn chỉnh');
    let finalContent = `# BÁO CÁO ĐÁNH GIÁ NHÂN VIÊN\n\n${aiReportContent}`;
    if (managerNote) {
      finalContent += `\n\n## ĐÁNH GIÁ THÊM TỪ QUẢN LÝ\n${managerNote}`;
    }

    try {
      const resp = await fetch('/api/reports', {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        },
        body: JSON.stringify({
          employee_id: selectedReportEmployeeId,
          content: finalContent
        })
      });
      if (resp.ok) {
        alert('Đã lưu báo cáo');
        setAiReportContent('');
        setManagerNote('');
        fetchReports();
        setReportTab('history');
      }
    } catch (err) {
      console.error(err);
    }
  };

  const exportPDF = async (report: any) => {
    // Create a temporary container to render the content beautifully for export
    const container = document.createElement('div');
    container.style.position = 'absolute';
    container.style.left = '-9999px';
    container.style.top = '0';
    container.style.width = '800px';
    container.style.padding = '40px';
    container.style.backgroundColor = '#ffffff';
    container.style.fontFamily = 'Inter, sans-serif';
    container.innerHTML = `
      <div style="border-bottom: 2px solid #6366f1; padding-bottom: 20px; margin-bottom: 30px;">
        <h1 style="color: #1e293b; font-size: 28px; margin: 0; font-weight: 800;">BÁO CÁO ĐÁNH GIÁ NHÂN VIÊN</h1>
        <div style="margin-top: 10px; color: #64748b; font-size: 14px;">
          <p style="margin: 2px 0;"><strong>Nhân viên:</strong> ${report.employee_name}</p>
          <p style="margin: 2px 0;"><strong>Ngày tạo:</strong> ${new Date(report.created_at).toLocaleDateString('vi-VN')}</p>
          <p style="margin: 2px 0;"><strong>Người lập:</strong> ${report.reporter_name}</p>
        </div>
      </div>
      <div style="color: #334155; line-height: 1.6; font-size: 14px; white-space: pre-wrap;">
        ${report.content.replace(/#/g, '').replace(/\*\*/g, '')}
      </div>
      <div style="margin-top: 50px; border-top: 1px solid #e2e8f0; padding-top: 20px; text-align: right; color: #94a3b8; font-size: 12px;">
        Hệ thống Quản lý Nhân sự v2.0 - © ${new Date().getFullYear()}
      </div>
    `;
    
    document.body.appendChild(container);
    
    try {
      const canvas = await html2canvas(container, {
        scale: 2, // High quality
        useCORS: true,
        logging: false,
        backgroundColor: '#ffffff'
      });
      
      const imgData = canvas.toDataURL('image/png');
      const pdf = new jsPDF('p', 'mm', 'a4');
      const pdfWidth = pdf.internal.pageSize.getWidth();
      const pdfHeight = (canvas.height * pdfWidth) / canvas.width;
      
      pdf.addImage(imgData, 'PNG', 0, 0, pdfWidth, pdfHeight);
      pdf.save(`Bao_cao_${report.employee_name.replace(/\s+/g, '_')}_${new Date().getTime()}.pdf`);
    } catch (error) {
      console.error('PDF Export Error:', error);
      alert('Có lỗi khi xuất PDF.');
    } finally {
      document.body.removeChild(container);
    }
  };

  const handleDeleteReport = async (id: number) => {
    if (!confirm('Xóa báo cáo này?')) return;
    try {
      await fetch(`/api/reports/${id}`, {
        method: 'DELETE',
        headers: { 'Authorization': `Bearer ${localStorage.getItem('token')}` }
      });
      fetchReports();
    } catch (err) {
      console.error(err);
    }
  };

  const openEditModal = (type: 'project' | 'task', item: any) => {
    setEditingItem(item);
    setFormData({ ...item });
    if (type === 'task') {
      fetchEvaluation(item.id);
      setEvalData({ rating: 5, comment: '' });
    }
    setShowModal(type);
  };

  const fetchEvaluation = async (taskId: number) => {
    try {
      const resp = await fetch(`/api/tasks/${taskId}/evaluation`, {
        headers: { 'Authorization': `Bearer ${localStorage.getItem('token')}` }
      });
      const data = await resp.json();
      setEvaluation(data);
    } catch (err) {
      console.error(err);
    }
  };

  const fetchProfile = async () => {
    try {
      const resp = await fetch('/api/profile', {
        headers: { 'Authorization': `Bearer ${localStorage.getItem('token')}` }
      });
      const data = await resp.json();
      setProfile(data);
      setProfileForm({
        email: data.email || '',
        phone: data.phone || '',
        address: data.address || '',
        bio: data.bio || '',
        avatar_url: data.avatar_url || ''
      });
    } catch (err) {
      console.error(err);
    }
  };

  const handleSaveProfile = async () => {
    try {
      const resp = await fetch('/api/profile', {
        method: 'PUT',
        headers: { 
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        },
        body: JSON.stringify(profileForm)
      });
      if (resp.ok) {
        setIsEditingProfile(false);
        fetchProfile();
      }
    } catch (err) {
      console.error(err);
    }
  };

  const openViewProject = async (project: Project) => {
    setEditingItem(project);
    setShowModal('view_project');
    try {
      const projectTasks = await apiService.fetchProjectTasks(project.id);
      setViewingProjectTasks(projectTasks);
    } catch (e) {
      console.error(e);
    }
  };

  const openViewTask = (task: Task) => {
    setEditingItem(task);
    setFormData({ ...task });
    // Nếu là admin hoặc là người được giao, mở modal task để có thể chỉnh sửa/cập nhật trạng thái
    if (currentUser?.role === 'admin' || task.assigned_to === currentUser?.id) {
      if (task.id) {
        fetchEvaluation(task.id);
        setEvalData({ rating: 5, comment: '' });
      }
      setShowModal('task');
    } else {
      setShowModal('view_task');
    }
  };

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    try {
      if (showModal === 'project') {
        if (editingItem) {
          await apiService.updateProject(editingItem.id, formData);
        } else {
          await apiService.createProject(formData);
        }
      } else if (showModal === 'task') {
        if (editingItem) {
          await apiService.updateTask(editingItem.id, formData);
          // If status is completed and it's an admin, we might need to save evaluation
          if (isAdmin && formData.status === 'completed' && !evaluation) {
            await fetch(`/api/tasks/${editingItem.id}/evaluate`, {
              method: 'POST',
              headers: { 
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${localStorage.getItem('token')}`
              },
              body: JSON.stringify({ ...evalData, employee_id: editingItem.assigned_to })
            });
          }
        } else {
          await apiService.createTask(formData);
        }
      } else if (showModal === 'employee') {
        const resp = await fetch('/api/employees', {
          method: 'POST',
          headers: { 
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${localStorage.getItem('token')}`
          },
          body: JSON.stringify(employeeFormData)
        });
        if (resp.ok) fetchData();
        else {
          const data = await resp.json();
          alert(data.message);
        }
      }
      setShowModal(null);
      fetchData();
    } catch (err: any) {
      console.error(err);
      alert(`Lỗi: ${err.message || 'Không thể lưu dữ liệu'}`);
    }
  };

  const handleDelete = async (type: 'project' | 'task', id: number) => {
    if (!confirm('Bạn có chắc chắn muốn xóa mục này?')) return;
    try {
      if (type === 'project') await apiService.deleteProject(id);
      else await apiService.deleteTask(id);
      fetchData();
    } catch (err: any) {
      console.error(err);
      alert(`Lỗi khi xóa: ${err.message || 'Không thể xóa dữ liệu'}`);
    }
  };

  if (!currentUser) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-slate-50 p-6">
        <motion.div 
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="w-full max-w-md overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-xl"
        >
          <div className="bg-indigo-600 p-8 text-center text-white">
            <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-2xl bg-white/10 backdrop-blur-md">
              <Database size={32} />
            </div>
            <h1 className="text-2xl font-bold tracking-tight">TaskFlow Management</h1>
            <p className="mt-2 text-indigo-100 opacity-80 text-sm">Hệ thống quản lý dự án & công việc</p>
          </div>
          
          <form className="p-8 space-y-6" onSubmit={handleLogin}>
            {error && (
              <div className="rounded-lg bg-rose-50 px-4 py-3 text-sm text-rose-600 border border-rose-100">
                {error}
              </div>
            )}
            <div className="space-y-4">
              <div>
                <label className="text-xs font-semibold uppercase tracking-wider text-slate-500">Tên đăng nhập</label>
                <input 
                  type="text" 
                  className="mt-1 block w-full rounded-xl border border-slate-200 px-4 py-3 text-sm transition-all focus:border-indigo-500 focus:ring-4 focus:ring-indigo-500/10 outline-none"
                  placeholder="admin hoặc employee"
                  value={authForm.username}
                  onChange={e => setAuthForm({...authForm, username: e.target.value})}
                  required
                />
              </div>
              <div>
                <label className="text-xs font-semibold uppercase tracking-wider text-slate-500">Mật khẩu</label>
                <input 
                  type="password" 
                  className="mt-1 block w-full rounded-xl border border-slate-200 px-4 py-3 text-sm transition-all focus:border-indigo-500 focus:ring-4 focus:ring-indigo-500/10 outline-none"
                  placeholder="••••••••"
                  value={authForm.password}
                  onChange={e => setAuthForm({...authForm, password: e.target.value})}
                  required
                />
              </div>
            </div>

            <button 
              type="submit"
              className="w-full rounded-xl bg-indigo-600 py-3 text-sm font-semibold text-white shadow-lg shadow-indigo-600/20 transition-all hover:bg-indigo-700 active:scale-95"
            >
              Đăng nhập hệ thống
            </button>
            
            <div className="text-center text-xs text-slate-400">
              Mặc định: admin/admin123 hoặc employee/user123
            </div>
          </form>
        </motion.div>
      </div>
    );
  }


  return (
    <div className="min-h-screen bg-slate-50 font-sans text-slate-900 flex">
      {/* Sidebar */}
      <aside className="w-72 bg-white border-r border-slate-200 flex flex-col sticky top-0 h-screen">
        <div className="p-6 border-b border-slate-100">
          <div className="flex items-center gap-3">
            <div className="rounded-xl bg-indigo-600 p-2.5 text-white">
              <Database size={22} />
            </div>
            <span className="text-lg font-bold tracking-tight">TaskFlow</span>
          </div>
        </div>

        <nav className="flex-1 p-4 space-y-1 overflow-y-auto">
          <NavItem 
            active={activeTab === 'projects'} 
            onClick={() => setActiveTab('projects')}
            icon={<Briefcase size={20} />}
            label="Quản lý dự án"
          />
          <NavItem 
            active={activeTab === 'tasks'} 
            onClick={() => setActiveTab('tasks')}
            icon={<ClipboardList size={20} />}
            label="Quản lý công việc"
            badge={unreadCount > 0 ? unreadCount : undefined}
          />
          {isAdmin && (
            <NavItem 
              active={activeTab === 'employees'} 
              onClick={() => setActiveTab('employees')}
              icon={<Users size={20} />}
              label="Quản lý nhân viên"
            />
          )}
          <NavItem 
            active={activeTab === 'reports'} 
            onClick={() => setActiveTab('reports')}
            icon={<BarChart3 size={20} />}
            label="Báo cáo"
          />
          <NavItem 
            active={activeTab === 'profile'} 
            onClick={() => setActiveTab('profile')}
            icon={<UserIcon size={20} />}
            label="Cá nhân"
          />
        </nav>

        <div className="p-6 border-t border-slate-100 bg-slate-50/50">
          <div 
            className="flex items-center gap-3 mb-6 cursor-pointer hover:bg-white hover:shadow-sm p-2 -m-2 rounded-xl transition-all"
            onClick={() => setActiveTab('profile')}
          >
            <div className="h-10 w-10 rounded-full bg-indigo-100 flex items-center justify-center text-indigo-600 ring-4 ring-white shadow-sm">
              <UserIcon size={20} />
            </div>
            <div className="overflow-hidden">
              <p className="text-sm font-bold truncate">{currentUser.fullname}</p>
              <p className="text-[10px] font-bold uppercase tracking-widest text-slate-400">
                {isAdmin ? 'Quản Lý' : 'Nhân Viên'}
              </p>
            </div>
          </div>
          <button 
            onClick={handleLogout}
            className="flex w-full items-center justify-center gap-2 rounded-xl border border-slate-200 bg-white py-2.5 text-sm font-semibold text-rose-600 transition-all hover:bg-rose-50 hover:border-rose-100"
          >
            <LogOut size={16} /> Đăng xuất
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 h-screen overflow-y-auto">
        <header className="bg-white/80 backdrop-blur-md border-b border-slate-200 px-8 py-4 sticky top-0 z-10 flex items-center justify-between">
          <div className="flex items-center gap-4 text-sm text-slate-500">
            <span>Hệ thống</span>
            <ChevronRight size={14} />
            <span className="font-medium text-slate-800">
              {activeTab === 'projects' ? 'Dự án' : 
               activeTab === 'tasks' ? 'Công việc' : 
               activeTab === 'employees' ? 'Nhân viên' : 
               activeTab === 'profile' ? 'Cá nhân' : 'Báo cáo'}
            </span>
          </div>
          
          <div className="flex items-center gap-4">
            <div className="relative">
              <button 
                onClick={() => setShowNotifPanel(!showNotifPanel)}
                className="relative rounded-xl border border-slate-200 bg-white p-2.5 text-slate-500 hover:bg-slate-50 transition-all active:scale-95"
              >
                <Bell size={20} />
                {unreadCount > 0 && (
                  <span className="absolute -top-1 -right-1 flex h-5 w-5 items-center justify-center rounded-full bg-rose-500 text-[10px] font-bold text-white ring-4 ring-white">
                    {unreadCount}
                  </span>
                )}
              </button>

              {showNotifPanel && (
                <div className="absolute right-0 mt-3 w-80 overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-2xl z-50">
                  <div className="bg-slate-50 px-4 py-3 border-b border-slate-200 flex justify-between items-center">
                    <span className="text-sm font-bold">Thông báo</span>
                    <button onClick={handleMarkRead} className="text-[10px] font-bold text-indigo-600 hover:underline uppercase tracking-wider">Đánh dấu đã đọc</button>
                  </div>
                  <div className="max-h-96 overflow-y-auto divide-y divide-slate-100">
                    {notifications.length > 0 ? (
                      notifications.map(n => (
                        <div key={n.id} className={`p-4 text-sm ${n.is_read ? 'opacity-60' : 'bg-indigo-50/30'}`}>
                          <p className="font-bold text-slate-800">{n.title}</p>
                          <p className="mt-1 text-slate-500 leading-relaxed">{n.message}</p>
                          <p className="mt-2 text-[10px] text-slate-400 font-medium">{new Date(n.created_at).toLocaleString('vi-VN')}</p>
                        </div>
                      ))
                    ) : (
                      <div className="p-8 text-center text-slate-400 text-xs">Không có thông báo mới</div>
                    )}
                  </div>
                </div>
              )}
            </div>

            {(activeTab === 'projects' || activeTab === 'tasks' || activeTab === 'employees') && (
              <div className="relative hidden lg:block">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={16} />
                <input 
                  type="text" 
                  placeholder={`Tìm kiếm ${activeTab === 'projects' ? 'dự án' : activeTab === 'tasks' ? 'công việc' : 'nhân viên'}...`}
                  className="rounded-full border border-slate-200 bg-slate-50 py-2 pl-10 pr-4 text-sm outline-none transition-all focus:bg-white focus:ring-4 focus:ring-indigo-500/10 w-72"
                  value={
                    activeTab === 'projects' ? projectsSearch : 
                    activeTab === 'tasks' ? tasksSearch : employeesSearch
                  }
                  onChange={e => {
                    const val = e.target.value;
                    if (activeTab === 'projects') setProjectsSearch(val);
                    else if (activeTab === 'tasks') setTasksSearch(val);
                    else setEmployeesSearch(val);
                  }}
                />
              </div>
            )}
            {isAdmin && (activeTab === 'projects' || activeTab === 'tasks' || activeTab === 'employees') && (
              <button 
                onClick={() => openCreateModal(activeTab === 'projects' ? 'project' : activeTab === 'tasks' ? 'task' : 'employee')}
                className="flex items-center gap-2 rounded-full bg-indigo-600 px-4 py-2 text-sm font-semibold text-white shadow-lg shadow-indigo-600/20 hover:bg-indigo-700 transition-all active:scale-95"
              >
                <Plus size={16} /> Tạo {activeTab === 'projects' ? 'Dự án' : activeTab === 'tasks' ? 'Công việc' : 'Nhân viên'}
              </button>
            )}
          </div>
        </header>

        <div className="p-8">
          <AnimatePresence mode="wait">
            <motion.div
              key={activeTab}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.2 }}
            >
              {activeTab === 'projects' && (
                <div className="space-y-6">
                  <div className="flex items-center justify-between">
                    <h2 className="text-2xl font-bold tracking-tight">Danh sách dự án</h2>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 min-h-[400px] content-start">
                    {loading ? (
                       Array.from({ length: 6 }).map((_, i) => <SkeletonCard key={i} />)
                    ) : filteredProjects.length > 0 ? (
                      filteredProjects.map(p => (
                        <div 
                          key={p.id} 
                          onClick={() => openViewProject(p)}
                          className="group rounded-2xl border border-slate-200 bg-white p-6 shadow-sm transition-all hover:shadow-md hover:border-indigo-200 cursor-pointer flex flex-col"
                        >
                          <div className="flex items-start justify-between gap-4 mb-4">
                            <h3 className="text-lg font-bold group-hover:text-indigo-600 transition-colors uppercase line-clamp-2 flex-1" title={p.name}>
                              {p.name}
                            </h3>
                            <div className="flex flex-col items-end gap-1.5 flex-shrink-0">
                              <div className={`rounded-full px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider ${
                                p.priority === 'high' ? 'bg-rose-100 text-rose-700' :
                                p.priority === 'medium' ? 'bg-amber-100 text-amber-700' : 'bg-slate-100 text-slate-500'
                              }`}>
                                {p.priority === 'high' ? 'Cao' : p.priority === 'medium' ? 'Trung bình' : 'Thấp'}
                              </div>
                              <div className={`rounded-full px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider ${
                                p.status === 'completed' ? 'bg-blue-100 text-blue-700' :
                                p.status === 'active' ? 'bg-emerald-100 text-emerald-700' : 'bg-slate-100 text-slate-500'
                              }`}>
                                {p.status === 'completed' ? 'Hoàn thành' : p.status === 'active' ? 'Đang chạy' : 'Tạm dừng'}
                              </div>
                            </div>
                          </div>
                          <p className="text-sm text-slate-500 line-clamp-2 mb-4 flex-1">{p.description}</p>
                          <div className="pt-4 border-t border-slate-100 flex items-center justify-between text-xs text-slate-400">
                            <span className="flex items-center gap-1.5"><Activity size={12}/> </span>
                            {isAdmin && (
                              <div className="flex gap-2" onClick={e => e.stopPropagation()}>
                                <button 
                                  onClick={() => openEditModal('project', p)}
                                  className="font-bold text-indigo-600 hover:text-indigo-800"
                                >SỬA</button>
                                <button 
                                  onClick={() => handleDelete('project', p.id)}
                                  className="font-bold text-rose-600 hover:text-rose-800"
                                >XÓA</button>
                              </div>
                            )}
                          </div>
                        </div>
                      ))
                    ) : (
                      <EmptyState text="Chưa có dự án nào" icon={<Briefcase size={48} />} />
                    )}
                  </div>
                </div>
              )}

              {activeTab === 'tasks' && (
                <div className="space-y-6">
                  <div className="flex items-center justify-between">
                    <h2 className="text-2xl font-bold tracking-tight">Danh sách công việc</h2>
                  </div>
                  
                  <div className="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm min-h-[400px]">
                    <table className="w-full text-left text-sm">
                      <thead className="bg-slate-50 text-slate-500 border-b border-slate-100">
                        <tr>
                          <th className="px-6 py-4 font-bold uppercase tracking-wider text-[10px]">Tiêu đề</th>
                          <th className="px-6 py-4 font-bold uppercase tracking-wider text-[10px]">Dự án</th>
                          <th className="px-6 py-4 font-bold uppercase tracking-wider text-[10px]">Người phụ trách</th>
                          <th className="px-6 py-4 font-bold uppercase tracking-wider text-[10px]">Trạng thái</th>
                          <th className="px-6 py-4 font-bold uppercase tracking-wider text-[10px]">Hạn chót</th>
                          {isAdmin && <th className="px-6 py-4 font-bold uppercase tracking-wider text-[10px]">Thao tác</th>}
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100">
                        {loading ? (
                          Array.from({ length: 5 }).map((_, i) => <SkeletonRow key={i} columns={isAdmin ? 6 : 5} />)
                        ) : filteredTasks.length > 0 ? (
                          filteredTasks.map(t => (
                            <tr 
                              key={t.id} 
                              onClick={() => openViewTask(t)}
                              className="hover:bg-slate-50/50 transition-colors cursor-pointer"
                            >
                              <td className="px-6 py-4 font-medium text-slate-800">{t.title}</td>
                              <td className="px-6 py-4 text-slate-500">{t.project_name}</td>
                              <td className="px-6 py-4">
                                <div className="flex items-center gap-2">
                                  <div className="h-6 w-6 rounded-full bg-blue-100 flex items-center justify-center text-[10px] font-bold text-blue-600">
                                    {t.assigned_name?.[0]}
                                  </div>
                                  <span className="text-slate-600">{t.assigned_name}</span>
                                </div>
                              </td>
                              <td className="px-6 py-4">
                                <span className={`inline-flex items-center rounded-full px-2 py-1 text-[10px] font-bold uppercase tracking-wider ${
                                  t.status === 'completed' ? 'bg-emerald-100 text-emerald-700' : 
                                  t.status === 'review' ? 'bg-amber-100 text-amber-700 border border-amber-200' :
                                  t.status === 'in_progress' ? 'bg-blue-100 text-blue-700' : 'bg-slate-100 text-slate-700'
                                }`}>
                                  {t.status === 'todo' ? 'Cần làm' : 
                                   t.status === 'in_progress' ? 'Đang thực hiện' :
                                   t.status === 'review' ? 'Chờ duyệt' : 'Hoàn thành'}
                                </span>
                              </td>
                              <td className="px-6 py-4 text-slate-500 text-xs font-mono">{t.due_date || 'N/A'}</td>
                              {isAdmin && (
                                <td className="px-6 py-4" onClick={e => e.stopPropagation()}>
                                  <div className="flex gap-3">
                                    <button 
                                      onClick={() => openEditModal('task', t)}
                                      className="text-indigo-600 hover:text-indigo-800 font-bold"
                                    >SỬA</button>
                                    <button 
                                      onClick={() => handleDelete('task', t.id)}
                                      className="text-rose-600 hover:text-rose-800 font-bold"
                                    >XÓA</button>
                                  </div>
                                </td>
                              )}
                            </tr>
                          ))
                        ) : (
                          <tr><td colSpan={isAdmin ? 6 : 5} className="py-20"><EmptyState text="Chưa có công việc nào" icon={<ClipboardList size={48} />} /></td></tr>
                        )}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}

              {activeTab === 'employees' && isAdmin && (
                <div className="space-y-6">
                  <h2 className="text-2xl font-bold tracking-tight">Cơ cấu nhân sự</h2>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 min-h-[400px] content-start">
                    {loading ? (
                      Array.from({ length: 4 }).map((_, i) => <SkeletonCard key={i} />)
                    ) : (
                      filteredEmployees.map(e => (
                        <div 
                          key={e.id} 
                          className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm text-center relative overflow-hidden group cursor-pointer hover:border-indigo-200 transition-all"
                          onClick={() => openViewEmployee(e)}
                        >
                           <div className="absolute top-0 inset-x-0 h-1 bg-indigo-600 opacity-0 group-hover:opacity-100 transition-opacity"></div>
                           <div className="mx-auto mb-4 h-16 w-16 rounded-full bg-slate-100 flex items-center justify-center text-slate-400 group-hover:bg-indigo-50 group-hover:text-indigo-600 transition-colors">
                              <UserIcon size={32} />
                           </div>
                           <h3 className="font-bold text-slate-900">{e.fullname}</h3>
                           <p className="text-xs text-slate-500 font-medium uppercase tracking-widest mt-1">@{e.username}</p>
                           <div className="mt-4 flex flex-col gap-3">
                             <div className="inline-flex items-center justify-center gap-1.5 rounded-full bg-slate-100 px-3 py-1 text-[10px] font-bold uppercase tracking-wider text-slate-600">
                               <Shield size={12}/> {e.role}
                             </div>
                             {isAdmin && e.id !== currentUser.id && (
                               <button 
                                 onClick={(event) => { event.stopPropagation(); handleDeleteEmployee(e.id); }}
                                 className="text-xs font-bold text-rose-600 hover:text-rose-800 transition-colors"
                               >
                                 Xóa tài khoản
                               </button>
                             )}
                           </div>
                        </div>
                      ))
                    )}
                  </div>
                </div>
              )}

              {activeTab === 'reports' && (
                <div className="space-y-6">
                  {/* Stats Bar Horizontal - Admin Only */}
                  {isAdmin && (
                    <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-2 flex flex-col sm:flex-row items-center divide-y sm:divide-y-0 sm:divide-x divide-slate-100">
                      <div className="flex-1 w-full p-4 flex items-center justify-center gap-4">
                        <div className="h-10 w-10 rounded-xl bg-indigo-50 flex items-center justify-center text-indigo-600">
                          <Briefcase size={20} />
                        </div>
                        <div>
                          <p className="text-[10px] font-black uppercase tracking-widest text-slate-400">Tổng dự án</p>
                          <p className="text-xl font-black text-slate-900">{projects.length}</p>
                        </div>
                      </div>
                      <div className="flex-1 w-full p-4 flex items-center justify-center gap-4">
                        <div className="h-10 w-10 rounded-xl bg-amber-50 flex items-center justify-center text-amber-600">
                          <ClipboardList size={20} />
                        </div>
                        <div>
                          <p className="text-[10px] font-black uppercase tracking-widest text-slate-400">Công việc</p>
                          <p className="text-xl font-black text-slate-900">{tasks.filter(t => t.status !== 'completed').length}</p>
                        </div>
                      </div>
                      <div className="flex-1 w-full p-4 flex items-center justify-center gap-4">
                        <div className="h-10 w-10 rounded-xl bg-emerald-50 flex items-center justify-center text-emerald-600">
                          <Users size={20} />
                        </div>
                        <div>
                          <p className="text-[10px] font-black uppercase tracking-widest text-slate-400">Nhân sự</p>
                          <p className="text-xl font-black text-slate-900">{employees.length}</p>
                        </div>
                      </div>
                    </div>
                  )}

                  <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                    <h2 className="text-2xl font-bold tracking-tight text-slate-800">
                      {isAdmin ? 'Quản lý hiệu suất AI' : 'Lịch sử báo cáo hiệu suất'}
                    </h2>
                    {isAdmin && (
                      <div className="flex p-1 bg-slate-200/50 rounded-xl">
                        <button 
                          onClick={() => setReportTab('generate')}
                          className={`px-4 py-2 text-xs font-bold uppercase tracking-wider rounded-lg transition-all ${reportTab === 'generate' ? 'bg-white text-indigo-600 shadow-md' : 'text-slate-500 hover:text-slate-800'}`}
                        >
                           Tạo báo cáo AI
                        </button>
                        <button 
                          onClick={() => setReportTab('history')}
                          className={`px-4 py-2 text-xs font-bold uppercase tracking-wider rounded-lg transition-all ${reportTab === 'history' ? 'bg-white text-indigo-600 shadow-md' : 'text-slate-500 hover:text-slate-800'}`}
                        >
                           Lịch sử báo cáo
                        </button>
                      </div>
                    )}
                  </div>

                  {reportTab === 'generate' && isAdmin ? (
                    <div className="grid grid-cols-1 xl:grid-cols-3 gap-8">
                      <div className="xl:col-span-1 space-y-6">
                        <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm space-y-6">
                           <div className="space-y-4">
                             <div className="flex items-center gap-2 text-indigo-600 font-bold mb-2">
                                <Activity size={20} />
                                <span>Cấu hình báo cáo</span>
                             </div>
                             
                             <div>
                               <label className="text-xs font-bold uppercase text-slate-400 tracking-wider">Chọn nhân viên</label>
                               <select 
                                 className="mt-1 w-full rounded-xl border border-slate-200 px-4 py-3 outline-none focus:ring-4 focus:ring-indigo-500/10"
                                 value={selectedReportEmployeeId}
                                 onChange={e => setSelectedReportEmployeeId(e.target.value)}
                               >
                                  <option value="">-- Chọn nhân viên --</option>
                                  {employees.map(emp => (
                                    <option key={emp.id} value={emp.id}>{emp.fullname} (@{emp.username})</option>
                                  ))}
                               </select>
                             </div>

                             <button 
                               onClick={generateAIReport}
                               disabled={isGeneratingAI}
                               className="w-full flex items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-indigo-600 to-violet-600 py-3.5 text-sm font-bold text-white shadow-lg shadow-indigo-200 hover:shadow-indigo-300 transition-all active:scale-95 disabled:opacity-50"
                             >
                               {isGeneratingAI ? (
                                 <>
                                   <div className="h-4 w-4 animate-spin rounded-full border-2 border-white/20 border-t-white"></div>
                                   Đang phân tích dữ liệu...
                                 </>
                               ) : (
                                 <>
                                   <Brain size={18} /> Generate with AI
                                 </>
                               )}
                             </button>
                           </div>

                           <div className="p-4 rounded-xl bg-indigo-50/50 border border-indigo-100">
                              <p className="text-[10px] uppercase font-black text-indigo-600 tracking-[0.2em] mb-2 text-center">Cách AI hoạt động</p>
                              <p className="text-xs text-slate-500 leading-relaxed">Hệ thống sẽ bảo mật việc tổng hợp dữ liệu. AI phân tích tất cả các nhận xét và điểm số của quản lý đã thực hiện cho nhân viên để đưa ra cái nhìn tổng quan nhất.</p>
                           </div>
                        </div>
                      </div>

                      <div className="xl:col-span-2 space-y-6">
                        {aiReportContent ? (
                          <div className="rounded-2xl border border-slate-200 bg-white overflow-hidden shadow-sm animate-in fade-in zoom-in-95 duration-500">
                             <div className="bg-indigo-600 p-4 text-white flex justify-between items-center">
                                <span className="font-bold text-sm">Kết quả phân tích AI</span>
                                <span className="text-[10px] font-bold uppercase bg-white/20 px-2 py-1 rounded">Draft</span>
                             </div>
                             <div className="p-6 space-y-6">
                                <div className="space-y-3">
                                   <label className="text-xs font-bold uppercase text-slate-400 tracking-wider">Bản thảo báo cáo</label>
                                   <textarea 
                                     className="w-full rounded-xl border border-slate-100 bg-slate-50 p-4 text-sm leading-relaxed outline-none focus:ring-4 focus:ring-indigo-500/10 min-h-[300px]"
                                     value={aiReportContent}
                                     onChange={e => setAiReportContent(e.target.value)}
                                   />
                                </div>

                                <div className="space-y-3 border-t border-slate-50 pt-6">
                                   <label className="text-xs font-bold uppercase text-slate-400 tracking-wider">Đánh giá thêm từ quản lý (Tùy chọn)</label>
                                   <textarea 
                                     placeholder="Bạn có muốn bổ sung gì thêm trước khi lưu không?"
                                     className="w-full rounded-xl border border-slate-200 p-4 text-sm outline-none focus:ring-4 focus:ring-indigo-500/10"
                                     rows={3}
                                     value={managerNote}
                                     onChange={e => setManagerNote(e.target.value)}
                                   />
                                </div>

                                <div className="pt-4 flex gap-4">
                                   <button 
                                     onClick={handleSaveReport}
                                     className="flex-1 rounded-xl bg-indigo-600 py-3.5 text-sm font-bold text-white shadow-xl shadow-indigo-200 transition-all hover:bg-indigo-700 active:scale-95"
                                   >
                                     Lưu báo cáo vào hệ thống
                                   </button>
                                   <button 
                                     onClick={() => setAiReportContent('')}
                                     className="px-6 rounded-xl border border-slate-200 text-sm font-bold text-slate-500 hover:bg-slate-50"
                                   >
                                     Hủy
                                   </button>
                                </div>
                             </div>
                          </div>
                        ) : (
                          <div className="rounded-2xl border-2 border-dashed border-slate-200 bg-white p-20 flex flex-col items-center justify-center text-center">
                             <div className="h-20 w-20 rounded-full bg-slate-50 flex items-center justify-center text-slate-200 mb-6">
                                <Brain size={48} />
                             </div>
                             <h3 className="text-lg font-bold text-slate-800">Chưa có dữ liệu báo cáo</h3>
                             <p className="max-w-xs text-slate-400 mt-2 text-sm">Chọn nhân viên ở cột bên trái và nhấn Generate để AI tiến hành phân tích và tổng hợp dữ liệu.</p>
                          </div>
                        )}
                      </div>
                    </div>
                  ) : (
                    <div className="space-y-6">
                       <div className="rounded-2xl border border-slate-200 bg-white overflow-hidden shadow-sm">
                          <table className="w-full text-left border-collapse">
                             <thead className="bg-slate-50 border-b border-slate-200">
                                <tr>
                                   <th className="px-6 py-4 text-[10px] font-bold uppercase tracking-widest text-slate-400">Nhân viên</th>
                                   <th className="px-6 py-4 text-[10px] font-bold uppercase tracking-widest text-slate-400">Người lập</th>
                                   <th className="px-6 py-4 text-[10px] font-bold uppercase tracking-widest text-slate-400">Ngày tạo</th>
                                   <th className="px-6 py-4 text-[10px] font-bold uppercase tracking-widest text-slate-400 text-right">Thao tác</th>
                                </tr>
                             </thead>
                             <tbody className="divide-y divide-slate-100">
                                {reports.length > 0 ? reports.map(r => (
                                   <tr key={r.id} className="hover:bg-slate-50/50 transition-colors group">
                                      <td className="px-6 py-4">
                                         <p className="font-bold text-slate-800">{r.employee_name}</p>
                                      </td>
                                      <td className="px-6 py-4">
                                         <p className="text-sm text-slate-600">{r.reporter_name}</p>
                                      </td>
                                      <td className="px-6 py-4">
                                         <p className="text-sm text-slate-400">{new Date(r.created_at).toLocaleDateString('vi-VN')}</p>
                                      </td>
                                      <td className="px-6 py-4 text-right">
                                         <div className="flex justify-end gap-2">
                                            <button 
                                              onClick={() => setViewingReport(r)}
                                              className="p-2 rounded-lg bg-indigo-50 text-indigo-600 hover:bg-indigo-100 transition-colors"
                                              title="Xem chi tiết"
                                            >
                                               <Layout size={16} />
                                            </button>
                                            <button 
                                              onClick={() => exportPDF(r)}
                                              className="p-2 rounded-lg bg-emerald-50 text-emerald-600 hover:bg-emerald-100 transition-colors"
                                              title="Tải PDF"
                                            >
                                               <HardDrive size={16} />
                                            </button>
                                            {isAdmin && (
                                              <button 
                                                onClick={() => handleDeleteReport(r.id)}
                                                className="p-2 rounded-lg bg-rose-50 text-rose-600 hover:bg-rose-100 transition-colors"
                                                title="Xóa"
                                              >
                                                 <Star size={16} />
                                              </button>
                                            )}
                                         </div>
                                      </td>
                                   </tr>
                                )) : (
                                   <tr>
                                      <td colSpan={4} className="px-6 py-12 text-center text-slate-400 italic text-sm">Chưa có báo cáo nào được lưu.</td>
                                   </tr>
                                )}
                             </tbody>
                          </table>
                       </div>
                    </div>
                  )}

                  {/* Modal xem báo cáo chi tiết */}
                  {viewingReport && (
                    <div className="fixed inset-0 z-[100] flex items-center justify-center bg-slate-900/60 backdrop-blur-sm p-4 animate-in fade-in duration-300">
                       <motion.div 
                         initial={{ y: 20, opacity: 0 }}
                         animate={{ y: 0, opacity: 1 }}
                         className="w-full max-w-3xl overflow-hidden rounded-3xl bg-white shadow-2xl flex flex-col max-h-[90vh]"
                       >
                          <div className="bg-slate-900 px-8 py-6 text-white flex justify-between items-center">
                             <div>
                                <h3 className="font-bold text-xl">Báo cáo hiệu suất công việc</h3>
                                <p className="text-xs text-slate-400 mt-1 uppercase tracking-widest font-medium">Bản chính thức • Lưu trữ hệ thống</p>
                             </div>
                             <button onClick={() => setViewingReport(null)} className="h-10 w-10 flex items-center justify-center rounded-xl bg-white/10 hover:bg-white/20 text-2xl transition-all">×</button>
                          </div>
                          
                          <div className="flex-1 overflow-y-auto p-12 bg-slate-50/30">
                             <div className="max-w-2xl mx-auto space-y-12 bg-white p-12 shadow-sm rounded-2xl border border-slate-100" id="report-to-pdf">
                                <div className="pb-12 border-b-2 border-slate-900/10 flex justify-between items-end">
                                   <div className="space-y-4">
                                      <div className="h-12 w-12 rounded-xl bg-indigo-600 flex items-center justify-center text-white">
                                         <Database size={24} />
                                      </div>
                                      <h2 className="text-2xl font-black text-slate-900 tracking-tight">TASKFLOW REPORT</h2>
                                   </div>
                                   <div className="text-right space-y-1">
                                      <p className="text-[10px] font-black uppercase text-slate-400 tracking-widest">Mã báo cáo</p>
                                      <p className="text-sm font-bold text-slate-900">#RP-{viewingReport.id}-{new Date(viewingReport.created_at).getTime().toString().slice(-4)}</p>
                                   </div>
                                </div>

                                <div className="grid grid-cols-2 gap-12">
                                   <div className="space-y-2">
                                      <p className="text-[10px] font-black uppercase text-slate-400 tracking-widest">Nhân sự được đánh giá</p>
                                      <p className="text-xl font-bold text-slate-900">{viewingReport.employee_name}</p>
                                      <p className="text-sm text-slate-500">ID: EMP-{viewingReport.employee_id}</p>
                                   </div>
                                   <div className="space-y-2 text-right">
                                      <p className="text-[10px] font-black uppercase text-slate-400 tracking-widest">Người thực hiện báo cáo</p>
                                      <p className="text-xl font-bold text-slate-900">{viewingReport.reporter_name}</p>
                                      <p className="text-sm text-slate-500">Ngày: {new Date(viewingReport.created_at).toLocaleDateString('vi-VN')}</p>
                                   </div>
                                </div>

                                <div className="space-y-8 pt-8 border-t border-slate-100 min-h-[400px]">
                                   <div className="prose prose-slate max-w-none whitespace-pre-wrap text-slate-700 leading-relaxed text-sm">
                                      {viewingReport.content}
                                   </div>
                                </div>
                                
                                <div className="pt-12 border-t border-slate-100 flex justify-between items-center opacity-50">
                                   <p className="text-[10px] font-medium text-slate-400">© 2024 TaskFlow Management System - AI Powered Reporting</p>
                                   <div className="h-4 w-4 bg-slate-900"></div>
                                </div>
                             </div>
                          </div>

                          <div className="p-8 bg-white border-t border-slate-100 flex gap-4">
                             <button 
                               onClick={() => exportPDF(viewingReport)}
                               className="flex-1 flex items-center justify-center gap-2 rounded-2xl bg-slate-900 py-4 text-sm font-bold text-white shadow-xl hover:bg-slate-800 transition-all"
                             >
                                <HardDrive size={18} /> Tải xuống bản PDF
                             </button>
                             <button 
                               onClick={() => setViewingReport(null)}
                               className="px-8 rounded-2xl border border-slate-200 text-sm font-bold text-slate-500 hover:bg-slate-50 transition-all"
                             >
                                Đóng
                             </button>
                          </div>
                       </motion.div>
                    </div>
                  )}
                </div>
              )}

              {activeTab === 'profile' && (
                <div className="max-w-4xl mx-auto space-y-6">
                  <h2 className="text-2xl font-bold tracking-tight">Hồ sơ cá nhân</h2>
                  
                  <div className="rounded-2xl border border-slate-200 bg-white p-8 shadow-sm">
                    <div className="flex flex-col md:flex-row gap-8 items-start">
                      <div className="flex-shrink-0 text-center space-y-4">
                        <div className="h-32 w-32 rounded-full bg-indigo-50 border-4 border-white shadow-md flex items-center justify-center text-indigo-200 overflow-hidden relative group">
                          {profileForm.avatar_url ? (
                            <img src={profileForm.avatar_url} alt="Avatar" className="h-full w-full object-cover" referrerPolicy="no-referrer" />
                          ) : (
                            <UserIcon size={64} />
                          )}
                        </div>
                        <div className="space-y-1">
                          <h3 className="text-xl font-bold text-slate-800">{currentUser.fullname}</h3>
                          <p className="text-sm text-slate-400 font-medium uppercase tracking-wider">@{currentUser.username} • {currentUser.role}</p>
                        </div>
                      </div>

                      <div className="flex-grow space-y-6">
                        {!isEditingProfile ? (
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div className="space-y-1">
                              <label className="text-[10px] font-bold uppercase text-slate-400 tracking-widest">Email</label>
                              <p className="text-slate-700">{profile?.email || 'Chưa cập nhật'}</p>
                            </div>
                            <div className="space-y-1">
                              <label className="text-[10px] font-bold uppercase text-slate-400 tracking-widest">Số điện thoại</label>
                              <p className="text-slate-700">{profile?.phone || 'Chưa cập nhật'}</p>
                            </div>
                            <div className="space-y-1 md:col-span-2">
                              <label className="text-[10px] font-bold uppercase text-slate-400 tracking-widest">Địa chỉ</label>
                              <p className="text-slate-700">{profile?.address || 'Chưa cập nhật'}</p>
                            </div>
                            <div className="space-y-1 md:col-span-2">
                              <label className="text-[10px] font-bold uppercase text-slate-400 tracking-widest">Giới thiệu</label>
                              <p className="text-slate-700 leading-relaxed">{profile?.bio || 'Chưa có thông tin giới thiệu.'}</p>
                            </div>
                            <div className="pt-4 md:col-span-2 border-t border-slate-50 flex justify-end">
                              <button 
                                onClick={() => setIsEditingProfile(true)}
                                className="rounded-xl bg-slate-100 px-6 py-2.5 text-sm font-bold text-slate-700 transition-all hover:bg-slate-200 active:scale-95"
                              >
                                Chỉnh sửa hồ sơ
                              </button>
                            </div>
                          </div>
                        ) : (
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 animate-in fade-in slide-in-from-bottom-2 duration-300">
                            <div className="space-y-2">
                              <label className="text-[10px] font-bold uppercase text-slate-400 tracking-widest">Email</label>
                              <input 
                                className="w-full rounded-xl border border-slate-200 px-4 py-2.5 text-sm outline-none focus:ring-4 focus:ring-indigo-500/10 transition-all"
                                value={profileForm.email}
                                onChange={e => setProfileForm({...profileForm, email: e.target.value})}
                              />
                            </div>
                            <div className="space-y-2">
                              <label className="text-[10px] font-bold uppercase text-slate-400 tracking-widest">Số điện thoại</label>
                              <input 
                                className="w-full rounded-xl border border-slate-200 px-4 py-2.5 text-sm outline-none focus:ring-4 focus:ring-indigo-500/10 transition-all"
                                value={profileForm.phone}
                                onChange={e => setProfileForm({...profileForm, phone: e.target.value})}
                              />
                            </div>
                            <div className="space-y-2 md:col-span-2">
                              <label className="text-[10px] font-bold uppercase text-slate-400 tracking-widest">Địa chỉ</label>
                              <input 
                                className="w-full rounded-xl border border-slate-200 px-4 py-2.5 text-sm outline-none focus:ring-4 focus:ring-indigo-500/10 transition-all"
                                value={profileForm.address}
                                onChange={e => setProfileForm({...profileForm, address: e.target.value})}
                              />
                            </div>
                            <div className="space-y-2 md:col-span-2">
                              <label className="text-[10px] font-bold uppercase text-slate-400 tracking-widest">Link ảnh đại diện</label>
                              <input 
                                className="w-full rounded-xl border border-slate-200 px-4 py-2.5 text-sm outline-none focus:ring-4 focus:ring-indigo-500/10 transition-all"
                                value={profileForm.avatar_url}
                                onChange={e => setProfileForm({...profileForm, avatar_url: e.target.value})}
                                placeholder="https://..."
                              />
                            </div>
                            <div className="space-y-2 md:col-span-2">
                              <label className="text-[10px] font-bold uppercase text-slate-400 tracking-widest">Giới thiệu bản thân</label>
                              <textarea 
                                className="w-full rounded-xl border border-slate-200 px-4 py-2.5 text-sm outline-none focus:ring-4 focus:ring-indigo-500/10 transition-all"
                                rows={4}
                                value={profileForm.bio}
                                onChange={e => setProfileForm({...profileForm, bio: e.target.value})}
                              />
                            </div>
                            <div className="pt-4 md:col-span-2 border-t border-slate-50 flex justify-end gap-3">
                              <button 
                                onClick={() => {
                                  setIsEditingProfile(false);
                                  setProfileForm({
                                    email: profile?.email || '',
                                    phone: profile?.phone || '',
                                    address: profile?.address || '',
                                    bio: profile?.bio || '',
                                    avatar_url: profile?.avatar_url || ''
                                  });
                                }}
                                className="rounded-xl border border-slate-200 px-6 py-2.5 text-sm font-bold text-slate-500 transition-all hover:bg-slate-50 active:scale-95"
                              >
                                Hủy bỏ
                              </button>
                              <button 
                                onClick={handleSaveProfile}
                                className="rounded-xl bg-indigo-600 px-6 py-2.5 text-sm font-bold text-white shadow-lg shadow-indigo-200 transition-all hover:bg-indigo-700 hover:shadow-indigo-300 active:scale-95"
                              >
                                Lưu thay đổi
                              </button>
                            </div>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </motion.div>
          </AnimatePresence>
        </div>

        {/* Modal Hệ thống */}
        {showModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/40 backdrop-blur-sm p-4">
            <motion.div 
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              className="w-full max-w-lg overflow-hidden rounded-2xl bg-white shadow-2xl"
            >
              <div className="bg-indigo-600 px-6 py-4 text-white flex justify-between items-center">
                <h3 className="font-bold">
                  {showModal === 'view_project' && 'Chi tiết dự án'}
                  {showModal === 'view_task' && 'Chi tiết công việc'}
                  {showModal === 'project' && (editingItem ? 'Cập nhật dự án' : 'Thêm mới dự án')}
                  {showModal === 'task' && (editingItem ? 'Cập nhật công việc' : 'Thêm mới công việc')}
                </h3>
                <button onClick={() => setShowModal(null)} className="opacity-70 hover:opacity-100 text-2xl px-2">×</button>
              </div>

              <div className="overflow-y-auto max-h-[85vh]">
                {showModal === 'view_project' && (
                  <div className="p-8 space-y-6">
                    <div className="space-y-4">
                      <h4 className="text-2xl font-bold text-slate-800">{editingItem?.name}</h4>
                      <div className="flex gap-4">
                        <span className={`rounded-full px-3 py-1 text-xs font-bold uppercase tracking-wider ${
                          editingItem?.priority === 'high' ? 'bg-rose-100 text-rose-700' :
                          editingItem?.priority === 'medium' ? 'bg-amber-100 text-amber-700' : 'bg-slate-100 text-slate-500'
                        }`}>
                           Ưu tiên: {editingItem?.priority === 'high' ? 'Cao' : editingItem?.priority === 'medium' ? 'Trung bình' : 'Thấp'}
                        </span>
                        <span className={`rounded-full px-3 py-1 text-xs font-bold uppercase tracking-wider ${
                          editingItem?.status === 'completed' ? 'bg-blue-100 text-blue-700' :
                          editingItem?.status === 'active' ? 'bg-emerald-100 text-emerald-700' : 'bg-slate-100 text-slate-500'
                        }`}>
                           Trạng thái: {editingItem?.status === 'completed' ? 'Hoàn thành' : editingItem?.status === 'active' ? 'Đang chạy' : 'Tạm dừng'}
                        </span>
                      </div>
                      <p className="text-slate-600 leading-relaxed">{editingItem?.description || 'Không có mô tả.'}</p>
                    </div>

                    <div className="border-t border-slate-100 pt-6">
                      <h5 className="text-xs font-bold uppercase text-slate-400 tracking-wider mb-4">Danh sách công việc ({viewingProjectTasks.length})</h5>
                      <div className="space-y-3">
                        {viewingProjectTasks.map(vt => (
                          <div 
                            key={vt.id} 
                            onClick={() => openViewTask(vt)}
                            className="flex items-center justify-between rounded-xl bg-slate-50 p-4 border border-slate-100 hover:border-indigo-300 cursor-pointer transition-colors"
                          >
                            <div>
                              <p className="text-sm font-bold text-slate-800">{vt.title}</p>
                              <p className="text-[10px] text-slate-400 mt-0.5 font-medium">Giao cho: {employees.find(e => e.id === vt.assigned_to)?.fullname || 'Chưa giao'}</p>
                            </div>
                            <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                              vt.status === 'completed' ? 'bg-emerald-100 text-emerald-600' : 
                              vt.status === 'review' ? 'bg-amber-100 text-amber-600 border border-amber-200' :
                              vt.status === 'in_progress' ? 'bg-blue-100 text-blue-600' : 
                              'bg-slate-100 text-slate-600'
                            }`}>
                              {vt.status === 'todo' ? 'Cần làm' : 
                               vt.status === 'in_progress' ? 'Đang làm' :
                               vt.status === 'review' ? 'Chờ duyệt' : 'Hoàn thành'}
                            </span>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                )}

                {showModal === 'view_task' && (
                  <div className="p-8 space-y-6">
                    <div className="space-y-4">
                      <h4 className="text-2xl font-bold text-slate-800">{editingItem?.title}</h4>
                      <div className="flex items-center gap-2 text-indigo-600 font-semibold mb-2">
                         <Briefcase size={16} />
                         <span className="text-sm">{projects.find(p => p.id === editingItem?.project_id)?.name || 'Dự án N/A'}</span>
                      </div>
                      <p className="text-slate-600 leading-relaxed">{editingItem?.description || 'Không có mô tả chi tiết.'}</p>
                    </div>

                    <div className="grid grid-cols-2 gap-4 border-t border-slate-100 pt-6">
                      <div className="space-y-1">
                        <p className="text-[10px] font-bold uppercase text-slate-400 tracking-wider">Trạng thái</p>
                        <span className={`inline-flex items-center rounded-full px-2 py-1 text-[10px] font-bold uppercase tracking-wider ${
                          editingItem?.status === 'completed' ? 'bg-emerald-100 text-emerald-700' : 
                          editingItem?.status === 'review' ? 'bg-indigo-100 text-indigo-700' :
                          editingItem?.status === 'in_progress' ? 'bg-blue-100 text-blue-700' : 'bg-slate-100 text-slate-700'
                        }`}>
                          {editingItem?.status === 'todo' ? 'Cần làm' : 
                           editingItem?.status === 'in_progress' ? 'Đang thực hiện' :
                           editingItem?.status === 'review' ? 'Đang duyệt' : 'Hoàn thành'}
                        </span>
                      </div>
                      <div className="space-y-1">
                        <p className="text-[10px] font-bold uppercase text-slate-400 tracking-wider">Hạn chót</p>
                        <p className="text-sm font-medium text-rose-500">{editingItem?.due_date || 'N/A'}</p>
                      </div>
                      <div className="space-y-1 col-span-2 mt-2">
                        <p className="text-[10px] font-bold uppercase text-slate-400 tracking-wider">Phụ trách</p>
                        <div className="flex items-center gap-2 font-medium text-sm">
                          {employees.find(e => e.id === editingItem?.assigned_to)?.fullname || 'Chưa giao'}
                        </div>
                      </div>
                    </div>
                    {evaluation && (
                      <div className="mx-8 mb-8 p-4 bg-blue-50 rounded-xl border border-blue-100">
                        <p className="text-xs font-bold uppercase text-blue-600 mb-2">Đánh giá hiệu quả</p>
                        <div className="flex gap-1 mb-2">
                          {Array.from({ length: 5 }).map((_, i) => (
                            <Star key={i} size={14} className={i < evaluation.rating ? 'fill-amber-400 text-amber-400' : 'text-slate-300'} />
                          ))}
                        </div>
                        <p className="text-sm text-slate-700">{evaluation.comment}</p>
                      </div>
                    )}
                  </div>
                )}

                {(showModal === 'project' || showModal === 'task' || showModal === 'employee') && (
                  <form className="p-6 space-y-4" onSubmit={handleSubmit}>
                    <div className="flex items-center justify-between">
                      <h2 className="text-xl font-bold text-slate-800">
                        {showModal === 'project' ? (editingItem ? 'Sửa dự án' : 'Tạo dự án') : 
                         showModal === 'task' ? (editingItem ? 'Sửa công việc' : 'Tạo công việc') : 
                         'Thêm nhân viên'}
                      </h2>
                    </div>
                    {showModal === 'employee' ? (
                      <div className="space-y-4">
                        <div>
                          <label className="text-xs font-bold uppercase text-slate-400 tracking-wider">Họ và tên</label>
                          <input 
                            className="mt-1 w-full rounded-xl border border-slate-200 px-4 py-2 outline-none focus:ring-4 focus:ring-indigo-500/10"
                            value={employeeFormData.fullname}
                            onChange={e => setEmployeeFormData({...employeeFormData, fullname: e.target.value})}
                            required
                            autoComplete="off"
                          />
                        </div>
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <label className="text-xs font-bold uppercase text-slate-400 tracking-wider">Tên đăng nhập</label>
                            <input 
                              className="mt-1 w-full rounded-xl border border-slate-200 px-4 py-2 outline-none focus:ring-4 focus:ring-indigo-500/10"
                              value={employeeFormData.username}
                              onChange={e => setEmployeeFormData({...employeeFormData, username: e.target.value})}
                              required
                              autoComplete="new-username"
                            />
                          </div>
                          <div>
                            <label className="text-xs font-bold uppercase text-slate-400 tracking-wider">Vai trò</label>
                            <select 
                              className="mt-1 w-full rounded-xl border border-slate-200 px-4 py-2"
                              value={employeeFormData.role}
                              onChange={e => setEmployeeFormData({...employeeFormData, role: e.target.value})}
                            >
                              <option value="employee">Nhân viên</option>
                              <option value="admin">Quản lý</option>
                            </select>
                          </div>
                        </div>
                        <div>
                          <label className="text-xs font-bold uppercase text-slate-400 tracking-wider">Mật khẩu</label>
                          <input 
                            type="password"
                            className="mt-1 w-full rounded-xl border border-slate-200 px-4 py-2 outline-none focus:ring-4 focus:ring-indigo-500/10"
                            value={employeeFormData.password}
                            onChange={e => setEmployeeFormData({...employeeFormData, password: e.target.value})}
                            required
                            autoComplete="new-password"
                          />
                        </div>
                      </div>
                    ) : showModal === 'project' ? (
                      <>
                        <div>
                          <label className="text-xs font-bold uppercase text-slate-400 tracking-wider">Tên dự án</label>
                          <input 
                            className="mt-1 w-full rounded-xl border border-slate-200 px-4 py-2 outline-none focus:ring-4 focus:ring-indigo-500/10"
                            value={formData.name || ''}
                            onChange={e => setFormData({ ...formData, name: e.target.value })}
                            required
                          />
                        </div>
                        <div>
                          <label className="text-xs font-bold uppercase text-slate-400 tracking-wider">Mô tả</label>
                          <textarea 
                            className="mt-1 w-full rounded-xl border border-slate-200 px-4 py-2 outline-none focus:ring-4 focus:ring-indigo-500/10"
                            rows={3}
                            value={formData.description || ''}
                            onChange={e => setFormData({ ...formData, description: e.target.value })}
                          />
                        </div>
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <label className="text-xs font-bold uppercase text-slate-400 tracking-wider">Trạng thái</label>
                            <select 
                              className="mt-1 w-full rounded-xl border border-slate-200 px-4 py-2"
                              value={formData.status || 'active'}
                              onChange={e => setFormData({ ...formData, status: e.target.value })}
                            >
                              <option value="active">Đang chạy</option>
                              <option value="inactive">Tạm dừng</option>
                              <option value="completed">Hoàn thành</option>
                            </select>
                          </div>
                          <div>
                            <label className="text-xs font-bold uppercase text-slate-400 tracking-wider">Ưu tiên</label>
                            <select 
                              className="mt-1 w-full rounded-xl border border-slate-200 px-4 py-2"
                              value={formData.priority || 'medium'}
                              onChange={e => setFormData({ ...formData, priority: e.target.value })}
                            >
                              <option value="high">Cao (High)</option>
                              <option value="medium">Trung bình (Medium)</option>
                              <option value="low">Thấp (Low)</option>
                            </select>
                          </div>
                        </div>
                        {!editingItem && (
                          <div className="pt-4 border-t border-slate-100">
                            <label className="text-xs font-bold uppercase text-indigo-600 tracking-wider mb-2 block">Công việc kèm theo</label>
                            <button 
                              type="button" 
                              onClick={() => setFormData({...formData, tasks: [...(formData.tasks || []), { title: '', assigned_to: '', due_date: '' }]})}
                              className="w-full py-2 bg-indigo-50 text-indigo-600 rounded-xl mb-3 flex items-center justify-center gap-2 text-xs font-bold"
                            >
                              <Plus size={14} /> Thêm công việc con
                            </button>
                            <div className="space-y-3 max-h-40 overflow-y-auto">
                              {(formData.tasks || []).map((t: any, idx: number) => (
                                <div key={idx} className="p-3 bg-slate-50 rounded-xl border border-slate-100 space-y-2">
                                  <input 
                                    placeholder="Tên công việc..." 
                                    className="w-full text-xs px-3 py-2 rounded-lg border border-slate-200"
                                    value={t.title}
                                    onChange={e => {
                                      const n = [...formData.tasks]; n[idx].title = e.target.value; setFormData({...formData, tasks: n});
                                    }}
                                    required
                                  />
                                  <select 
                                    className="w-full text-[10px] px-3 py-2 rounded-lg border border-slate-200"
                                    value={t.assigned_to}
                                    onChange={e => {
                                      const n = [...formData.tasks]; n[idx].assigned_to = e.target.value; setFormData({...formData, tasks: n});
                                    }}
                                    required
                                  >
                                    <option value="">Giao cho...</option>
                                    {employees.map(emp => <option key={emp.id} value={emp.id}>{emp.fullname}</option>)}
                                  </select>
                                </div>
                              ))}
                            </div>
                          </div>
                        )}
                      </>
                    ) : (
                      <>
                        {!isAdmin && editingItem ? (
                          <div className="space-y-4">
                            <div>
                              <p className="text-sm font-bold text-slate-800 mb-1">{editingItem.title}</p>
                              <p className="text-xs text-slate-500 mb-4">{editingItem.description}</p>
                            </div>
                            <div>
                              <label className="text-xs font-bold uppercase text-slate-400 tracking-wider">Cập nhật trạng thái</label>
                              <select 
                                className="mt-1 w-full rounded-xl border border-slate-200 px-4 py-2 text-sm"
                                value={formData.status || 'todo'}
                                onChange={e => setFormData({ ...formData, status: e.target.value })}
                              >
                                <option value="todo">Cần làm (Todo)</option>
                                <option value="in_progress">Đang thực hiện (In Progress)</option>
                                <option value="review" disabled>Đang chờ duyệt (Review)</option>
                                <option value="completed">Đã xong (Gửi duyệt)</option>
                              </select>
                              <p className="mt-2 text-[10px] text-slate-400 italic">* Nhân viên chỉ có quyền cập nhật tiến độ công việc.</p>
                            </div>
                            {evaluation && (
                              <div className="p-4 bg-blue-50 rounded-xl border border-blue-100">
                                <p className="text-xs font-bold uppercase text-blue-600 mb-2">Đánh giá từ quản lý</p>
                                <div className="flex gap-1 mb-2">
                                  {Array.from({ length: 5 }).map((_, i) => (
                                    <Star key={i} size={14} className={i < evaluation.rating ? 'fill-amber-400 text-amber-400' : 'text-slate-300'} />
                                  ))}
                                </div>
                                <p className="text-sm text-slate-700">{evaluation.comment}</p>
                              </div>
                            )}
                          </div>
                        ) : (
                          <>
                            <div>
                              <label className="text-xs font-bold uppercase text-slate-400 tracking-wider">Tiêu đề công việc</label>
                              <input 
                                className="mt-1 w-full rounded-xl border border-slate-200 px-4 py-2 outline-none focus:ring-4 focus:ring-indigo-500/10"
                                value={formData.title || ''}
                                onChange={e => setFormData({ ...formData, title: e.target.value })}
                                required
                              />
                            </div>
                            <div className="grid grid-cols-2 gap-4">
                              <div>
                                <label className="text-xs font-bold uppercase text-slate-400 tracking-wider">Dự án</label>
                                <select 
                                  className="mt-1 w-full rounded-xl border border-slate-200 px-4 py-2"
                                  value={formData.project_id || ''}
                                  onChange={e => setFormData({ ...formData, project_id: e.target.value })}
                                  required
                                >
                                  <option value="">Chọn dự án...</option>
                                  {projects.filter(p => p.status !== 'completed' || p.id === formData.project_id).map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
                                </select>
                              </div>
                              <div>
                                <label className="text-xs font-bold uppercase text-slate-400 tracking-wider">Giao cho</label>
                                <select 
                                  className="mt-1 w-full rounded-xl border border-slate-200 px-4 py-2"
                                  value={formData.assigned_to || ''}
                                  onChange={e => setFormData({ ...formData, assigned_to: e.target.value })}
                                >
                                  <option value="">Chưa giao...</option>
                                  {employees.map(emp => <option key={emp.id} value={emp.id}>{emp.fullname}</option>)}
                                </select>
                              </div>
                            </div>
                            <div className="grid grid-cols-2 gap-4">
                              <div>
                                <label className="text-xs font-bold uppercase text-slate-400 tracking-wider">Trạng thái</label>
                                <select 
                                  className="mt-1 w-full rounded-xl border border-slate-200 px-4 py-2"
                                  value={formData.status || 'todo'}
                                  onChange={e => setFormData({ ...formData, status: e.target.value })}
                                >
                                  <option value="todo">Todo (Cần làm)</option>
                                  <option value="in_progress">In Progress (Đang thực hiện)</option>
                                  <option value="review">Review (Đang duyệt)</option>
                                  <option value="completed">Completed (Hoàn thành)</option>
                                </select>
                              </div>
                              <div>
                                <label className="text-xs font-bold uppercase text-slate-400 tracking-wider">Hạn chót</label>
                                <input 
                                  type="date"
                                  className="mt-1 w-full rounded-xl border border-slate-200 px-4 py-2"
                                  value={formData.due_date || ''}
                                  onChange={e => setFormData({ ...formData, due_date: e.target.value })}
                                />
                              </div>
                            </div>
                            <div>
                              <label className="text-xs font-bold uppercase text-slate-400 tracking-wider">Mô tả</label>
                              <textarea 
                                className="mt-1 w-full rounded-xl border border-slate-200 px-4 py-2 outline-none focus:ring-4 focus:ring-indigo-500/10"
                                rows={2}
                                value={formData.description || ''}
                                onChange={e => setFormData({ ...formData, description: e.target.value })}
                              />
                            </div>
                            {editingItem && isAdmin && formData.status === 'completed' && !evaluation && (
                              <div className="p-4 bg-indigo-50 border border-indigo-100 rounded-xl space-y-3">
                                <label className="text-xs font-bold uppercase text-indigo-600 tracking-wider block">Đánh giá nhân viên</label>
                                <div className="flex gap-2">
                                  {[1, 2, 3, 4, 5].map(star => (
                                    <button 
                                      key={star}
                                      type="button" 
                                      onClick={() => setEvalData({...evalData, rating: star})}
                                      className={`p-1 transition-colors ${evalData.rating >= star ? 'text-amber-400' : 'text-slate-300 hover:text-amber-200'}`}
                                    >
                                      <Star size={20} fill={evalData.rating >= star ? 'currentColor' : 'none'} />
                                    </button>
                                  ))}
                                </div>
                                <textarea 
                                  placeholder="Nhập nhận xét về hiệu quả công việc..."
                                  className="w-full text-sm p-3 rounded-lg border border-slate-200 focus:ring-4 focus:ring-indigo-500/10 outline-none"
                                  rows={2}
                                  value={evalData.comment}
                                  onChange={e => setEvalData({...evalData, comment: e.target.value})}
                                />
                              </div>
                            )}
                            {evaluation && isAdmin && (
                               <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl">
                                 <p className="text-xs font-bold uppercase text-slate-500 mb-2">Đã đánh giá</p>
                                 <div className="flex gap-1 mb-2">
                                  {Array.from({ length: 5 }).map((_, i) => (
                                    <Star key={i} size={14} className={i < evaluation.rating ? 'fill-amber-400 text-amber-400' : 'text-slate-300'} />
                                  ))}
                                </div>
                                <p className="text-sm text-slate-700 italic">"{evaluation.comment}"</p>
                               </div>
                            )}
                          </>
                        )}
                      </>
                    )}
                    <div className="pt-4 flex gap-3">
                      <button type="submit" className="flex-1 rounded-xl bg-indigo-600 py-3 text-sm font-bold text-white shadow-lg shadow-indigo-600/20 hover:bg-indigo-700">
                        Lưu dữ liệu
                      </button>
                      <button type="button" onClick={() => setShowModal(null)} className="px-6 rounded-xl border border-slate-200 text-sm font-bold text-slate-500 hover:bg-slate-50">
                        Hủy
                      </button>
                    </div>
                  </form>
                )}
                {showModal === 'view_employee' && selectedEmployee && (
                  <div className="p-8 space-y-6">
                    <div className="flex items-center gap-4 mb-2">
                       <div className="h-16 w-16 rounded-full bg-indigo-50 flex items-center justify-center text-indigo-600 ring-4 ring-white shadow-sm">
                          <UserIcon size={32} />
                       </div>
                       <div>
                          <h3 className="text-xl font-bold text-slate-900">{selectedEmployee.fullname}</h3>
                          <p className="text-xs text-slate-500 font-medium tracking-widest uppercase mt-0.5">@{selectedEmployee.username} • {selectedEmployee.role}</p>
                       </div>
                    </div>

                    <div className="space-y-6">
                       <div className="space-y-3">
                          <h4 className="text-xs font-bold uppercase text-slate-400 tracking-widest border-b border-slate-100 pb-2">Dự án tham gia</h4>
                          <div className="grid grid-cols-1 gap-2 max-h-40 overflow-y-auto">
                             {selectedEmployeeWork?.projects.length > 0 ? selectedEmployeeWork.projects.map((p: any) => (
                                <div key={p.id} className="p-3 rounded-xl bg-slate-50 border border-slate-100 flex justify-between items-center">
                                   <span className="text-sm font-semibold text-slate-700">{p.name}</span>
                                   <span className="text-[10px] font-bold uppercase py-0.5 px-2 bg-white rounded-full text-slate-500">{p.status}</span>
                                </div>
                             )) : <p className="text-sm text-slate-400 italic">Chưa có dự án nào.</p>}
                          </div>
                       </div>

                       <div className="space-y-3">
                          <h4 className="text-xs font-bold uppercase text-slate-400 tracking-widest border-b border-slate-100 pb-2">Công việc đang làm</h4>
                          <div className="space-y-2 max-h-60 overflow-y-auto pr-1">
                             {selectedEmployeeWork?.tasks.length > 0 ? selectedEmployeeWork.tasks.map((t: any) => (
                                <div key={t.id} className="p-4 rounded-xl border border-slate-100 bg-white shadow-sm flex justify-between items-center group">
                                   <div className="space-y-1">
                                      <p className="text-sm font-bold text-slate-800 group-hover:text-indigo-600 transition-colors">{t.title}</p>
                                      <p className="text-[10px] text-slate-400">Dự án: {t.project_name}</p>
                                   </div>
                                   <span className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded-full ${t.status === 'completed' ? 'bg-emerald-50 text-emerald-600' : 'bg-amber-50 text-amber-600'}`}>
                                      {t.status}
                                   </span>
                                </div>
                             )) : <p className="text-sm text-slate-400 italic">Chưa có công việc nào.</p>}
                          </div>
                       </div>
                    </div>
                    
                    <button 
                      onClick={() => setShowModal(null)} 
                      className="w-full py-3 rounded-xl border border-slate-200 text-sm font-bold text-slate-600 hover:bg-slate-50 transition-all mt-4"
                    >
                      Đóng
                    </button>
                  </div>
                )}
              </div>
            </motion.div>
          </div>
        )}
      </main>
    </div>
  );
}

function NavItem({ active, onClick, icon, label, badge }: { active: boolean; onClick: () => void; icon: ReactNode; label: string; badge?: number }) {
  return (
    <button 
      onClick={onClick}
      className={`flex w-full items-center gap-3 rounded-xl px-4 py-3 text-sm font-semibold transition-all relative ${
        active 
          ? 'bg-indigo-50 text-indigo-700 shadow-sm' 
          : 'text-slate-500 hover:bg-slate-50 hover:text-slate-800'
      }`}
    >
      <span className={active ? 'text-indigo-600' : 'opacity-60'}>{icon}</span>
      <span className="flex-1 text-left">{label}</span>
      {badge !== undefined && (
        <span className="flex h-5 min-w-[20px] items-center justify-center rounded-full bg-rose-500 px-1 text-[10px] font-bold text-white">
          {badge}
        </span>
      )}
    </button>
  );
}

function EmptyState({ text, icon }: { text: string; icon: ReactNode }) {
  return (
    <div className="col-span-full py-20 flex flex-col items-center justify-center text-center text-slate-400">
      <div className="mb-4 opacity-20">{icon}</div>
      <p className="text-sm font-medium">{text}</p>
    </div>
  );
}

function SkeletonCard() {
  return (
    <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm animate-pulse">
      <div className="h-6 w-32 rounded bg-slate-100 mb-4"></div>
      <div className="h-4 w-full rounded bg-slate-100 mb-2"></div>
      <div className="h-4 w-2/3 rounded bg-slate-100"></div>
      <div className="mt-6 pt-4 border-t border-slate-100 flex justify-between">
         <div className="h-4 w-24 rounded bg-slate-100"></div>
         <div className="h-4 w-12 rounded bg-slate-100"></div>
      </div>
    </div>
  );
}

function SkeletonRow({ columns }: { columns: number, key?: any }) {
  return (
    <tr className="animate-pulse">
      {Array.from({ length: columns }).map((_, i) => (
        <td key={i} className="px-6 py-4"><div className="h-4 w-full rounded bg-slate-100"></div></td>
      ))}
    </tr>
  );
}

function ReportMetric({ label, value, description }: { label: string; value: string; description: string }) {
  return (
    <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
      <p className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-400">{label}</p>
      <div className="mt-3 flex items-baseline gap-2">
        <h4 className="text-4xl font-black text-slate-900 tracking-tight">{value}</h4>
        <span className="text-xs font-bold text-slate-400">{description}</span>
      </div>
    </div>
  );
}
